# seed_data.py
from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.infrastructure import Infrastructure

app = create_app()
app.app_context().push()

# create tables (migrations preferred)
db.create_all()

# Helper to create a user only when the username doesn't already exist
def create_user_if_not_exists(username, email, role, password, address=None, contact_number=None):
    existing = User.query.filter_by(username=username).first()
    if existing:
        return existing

    user = User(
        username=username,
        email=email,
        role=role,
        address=address or "",
        contact_number=contact_number or "",
    )
    user.set_password(password)
    db.session.add(user)
    return user

# Create admin (safe)
create_user_if_not_exists("admin", "admin@example.com", "admin", "admin123")

# Create some test resident accounts
test_residents = [
    ("resident1", "resident1@example.com", "resident123", "123 Poblacion St.", "09171234567"),
    ("resident2", "resident2@example.com", "resident123", "45 Market Ave.", "09177654321"),
    ("testuser", "testuser@example.com", "testpass", "67 Barangay Rd.", "09170001111"),
]

for u in test_residents:
    create_user_if_not_exists(u[0], u[1], "resident", u[2], address=u[3], contact_number=u[4])

# Seed a sample infrastructure entry if missing
if Infrastructure.query.count() == 0:
    infra = Infrastructure(name="Main Road", infra_type="Road", location="Zone 1", condition="Good")
    db.session.add(infra)

db.session.commit()
print("Seeding done.")
