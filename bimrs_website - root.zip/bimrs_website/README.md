# Barangay Infrastructure Maintenance Request System

A Flask web system where residents of **Población Barangay III** can report infrastructure problems with images, and admins can manage, track, and resolve reports using a Facebook-style feed.

---

## 🚀 Features
- Resident registration with address validation (must be Población Barangay III)
- Infrastructure management (CRUD)
- Submit reports with images
- Admin feed (Facebook-like)
- Logs, feedback, automatic email notifications
- SQLite database (default)

---

## 📦 Setup Instructions

### 1. Create Virtual Environment
