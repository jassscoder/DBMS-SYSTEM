import os

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY") or "super-secret-key"

    # ===== MySQL DATABASE URI =====
    DB_USER = os.environ.get("DB_USER", "root")
    DB_PASS = os.environ.get("DB_PASS", "")
    DB_HOST = os.environ.get("DB_HOST", "127.0.0.1")
    DB_NAME = os.environ.get("DB_NAME", "bimrs")


    # Prefer explicit DATABASE_URL if provided; otherwise build a MySQL URI
    # Use PyMySQL driver on Windows if available. Allow override with DATABASE_URL.
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL") or (
        f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}/{DB_NAME}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # ===== EMAIL SETTINGS =====
    MAIL_SERVER = "smtp.gmail.com"
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD")

    # UPLOAD PATH
    UPLOAD_FOLDER = os.path.join(os.getcwd(), "app", "uploads")
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB


