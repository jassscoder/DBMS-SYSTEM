import os
import pymysql

host = os.environ.get('DB_HOST', '127.0.0.1')
user = os.environ.get('DB_USER', 'root')
passwd = os.environ.get('DB_PASS', '')
db = os.environ.get('DB_NAME', 'bimrs')

out_path = os.path.join(os.path.dirname(__file__), 'check_db_counts_direct_result.txt')

try:
    conn = pymysql.connect(host=host, user=user, password=passwd, db=db, connect_timeout=5)
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM users')
    u_count = cur.fetchone()[0]
    cur.execute('SELECT COUNT(*) FROM infrastructure')
    i_count = cur.fetchone()[0]
    cur.close()
    conn.close()
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(f"users_count={u_count}\n")
        f.write(f"infrastructure_count={i_count}\n")
except Exception as e:
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write('ERROR:\n')
        f.write(str(e))
    raise
