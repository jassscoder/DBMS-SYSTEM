import os
import pymysql
import traceback

host = os.environ.get('DB_HOST', '127.0.0.1')
user = os.environ.get('DB_USER', 'root')
passwd = os.environ.get('DB_PASS', '')
db = os.environ.get('DB_NAME', 'bimrs')

out_path = os.path.join(os.path.dirname(__file__), 'db_connect_result.txt')

try:
    conn = pymysql.connect(host=host, user=user, password=passwd, db=db, connect_timeout=5)
    conn.close()
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(f"OK\nConnected to {user}@{host}/{db}\n")
except Exception:
    err = traceback.format_exc()
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write("ERROR\n")
        f.write(err)
    raise
