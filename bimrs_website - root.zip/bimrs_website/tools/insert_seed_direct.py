import os
import pymysql
from werkzeug.security import generate_password_hash

host = os.environ.get('DB_HOST', '127.0.0.1')
user = os.environ.get('DB_USER', 'root')
passwd = os.environ.get('DB_PASS', '')
db = os.environ.get('DB_NAME', 'bimrs')

out_path = os.path.join(os.path.dirname(__file__), 'insert_seed_direct_result.txt')

try:
    conn = pymysql.connect(host=host, user=user, password=passwd, db=db, connect_timeout=5)
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM users')
    u_count = cur.fetchone()[0]
    cur.execute('SELECT COUNT(*) FROM infrastructure')
    i_count = cur.fetchone()[0]

    if u_count == 0:
        pwd = generate_password_hash('admin123')
        cur.execute("INSERT INTO users (username, email, address, contact_number, password_hash, role) VALUES (%s,%s,%s,%s,%s,%s)",
                    ('admin','admin@example.com','', '', pwd, 'admin'))
        conn.commit()
    if i_count == 0:
        cur.execute("INSERT INTO infrastructure (name, category, barangay, status) VALUES (%s,%s,%s,%s)",
                    ('Main Road','Road','Zone 1','Good'))
        conn.commit()

    cur.close()
    conn.close()
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write('OK\n')
        f.write(f'users_inserted={1 if u_count==0 else 0}\n')
        f.write(f'infrastructure_inserted={1 if i_count==0 else 0}\n')
except Exception as e:
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write('ERROR\n')
        f.write(str(e))
    raise
