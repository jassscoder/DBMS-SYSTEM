import requests
r = requests.get('http://127.0.0.1:5000/auth/login')
open('tools/auth_login_response.html','wb').write(r.content)
print('STATUS', r.status_code)
