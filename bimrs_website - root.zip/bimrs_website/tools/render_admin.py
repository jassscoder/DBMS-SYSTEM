import os, sys
this_dir = os.path.dirname(os.path.dirname(__file__))
if this_dir not in sys.path:
    sys.path.insert(0, this_dir)
from app import create_app
from flask import render_template
app = create_app()
with app.app_context():
    try:
        html = render_template('admin/dashboard.html', total_reports=1, pending=0, resolved=0)
        open('tools/admin_render_output.html','w',encoding='utf-8').write(html)
        print('WROTE admin_render_output.html')
    except Exception as e:
        open('tools/admin_render_error.txt','w',encoding='utf-8').write(str(e))
        print('ERROR', e)
