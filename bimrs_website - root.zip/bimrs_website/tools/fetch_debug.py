import requests
for path in ['/','/auth/login','/debug-login']:
    r=requests.get('http://127.0.0.1:5000'+path)
    outfile = 'tools/resp'+path.replace('/','_')+'.html'
    open(outfile,'wb').write(r.content)
    print(path, r.status_code, len(r.content), r.headers.get('Content-Type'))
