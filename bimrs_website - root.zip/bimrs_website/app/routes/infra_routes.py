from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.forms.infra_forms import InfrastructureForm
from app.models.infrastructure import Infrastructure

infra_bp = Blueprint("infra", __name__, url_prefix="/infrastructure")

@infra_bp.route("/", methods=["GET", "POST"])
@login_required
def manage():
    form = InfrastructureForm()

    try:
        infras = Infrastructure.query.order_by(Infrastructure.name.asc()).all()
    except SQLAlchemyError:
        db.session.rollback()
        infras = []
        flash("Unable to load infrastructure data right now.", "danger")

    if form.validate_on_submit():
        try:
            infra = Infrastructure(
                name=form.name.data,
                category=form.category.data,
                barangay=form.barangay.data,
                status=form.status.data
            )

            db.session.add(infra)
            db.session.commit()
            flash("Infrastructure added!", "success")
            return redirect(url_for("infra.manage"))
        except SQLAlchemyError:
            db.session.rollback()
            flash("Failed to save infrastructure. Please try again.", "danger")

    return render_template("admin/infrastructures.html", form=form, infras=infras)
