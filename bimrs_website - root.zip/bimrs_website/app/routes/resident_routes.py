from flask import Blueprint, render_template
from flask_login import login_required, current_user
from app.models.report import Report

resident_bp = Blueprint("resident", __name__, url_prefix="/resident")

@resident_bp.route("/dashboard")
@login_required
def dashboard():
    # Defensive DB access: if DB isn't initialized, show an empty list instead of failing
    try:
        my_reports = Report.query.filter_by(reporter_id=current_user.id).all()
    except Exception:
        my_reports = []

    return render_template("resident/my_reports.html", reports=my_reports)
