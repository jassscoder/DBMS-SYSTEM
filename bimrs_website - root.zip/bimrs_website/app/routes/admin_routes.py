from flask import Blueprint, render_template
from flask_login import login_required
from app.models.report import Report
from app.models.infrastructure import Infrastructure

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

@admin_bp.route("/dashboard")
@login_required
def dashboard():
    # Guard DB queries to avoid rendering failures if the DB session isn't available
    try:
        total_reports = Report.query.count()
        pending = Report.query.filter_by(status="PENDING").count()
        in_progress = Report.query.filter_by(status="IN_PROGRESS").count()
        resolved = Report.query.filter_by(status="RESOLVED").count()

        infras = Infrastructure.query.count()
    except Exception:
        # If something goes wrong (missing DB, migrations, etc.), fall back to zeros
        total_reports = 0
        pending = 0
        in_progress = 0
        resolved = 0
        infras = 0

    return render_template("admin/dashboard.html",
                           total_reports=total_reports,
                           pending=pending,
                           in_progress=in_progress,
                           resolved=resolved,
                           infras=infras)

@admin_bp.route("/reports")
@login_required
def feed():
    try:
        reports = Report.query.order_by(Report.created_at.desc()).all()
    except Exception:
        reports = []
    return render_template("admin/reports_feed.html", reports=reports)
