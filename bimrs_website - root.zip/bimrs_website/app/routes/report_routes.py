from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.forms.report_forms import ReportForm
from app.models.report import Report
from app.utils.image_helpers import save_image
from app.utils.validation import is_address_in_barangay
from app.utils.email_helpers import send_resolution_email
from datetime import datetime

report_bp = Blueprint("reports", __name__, url_prefix="/reports")

# CREATE REPORT
@report_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_report():
    form = ReportForm()

    if form.validate_on_submit():
        if not is_address_in_barangay(form.address.data):
            flash("Report rejected — address must be within Población Barangay III.", "danger")
            return render_template("resident/submit_report.html", form=form)

        filename = save_image(form.image.data) if form.image.data else None

        report = Report(
            reporter_id=current_user.id,
            title=form.title.data,
            category=form.category.data,
            description=form.description.data,
            address=form.address.data,
            contact_number=form.contact_number.data,
            image_path=filename,
            status="PENDING"
        )

        db.session.add(report)
        db.session.commit()

        flash("Report submitted!", "success")
        return redirect(url_for("resident.dashboard"))

    return render_template("resident/submit_report.html", form=form)

# UPDATE STATUS (admin)
@report_bp.route("/<int:report_id>/update_status", methods=["POST"])
@login_required
def update_status(report_id):
    report = Report.query.get_or_404(report_id)
    new_status = request.form.get("status")
    valid_statuses = {"PENDING", "IN_PROGRESS", "RESOLVED"}

    if new_status not in valid_statuses:
        flash("Invalid status selected.", "danger")
        return redirect(url_for("admin.feed"))

    report.status = new_status
    if new_status == "RESOLVED":
        report.resolved_at = datetime.utcnow()
    else:
        report.resolved_at = None

    try:
        db.session.commit()
        if new_status == "RESOLVED":
            send_resolution_email(report)
        flash("Status updated!", "success")
    except SQLAlchemyError:
        db.session.rollback()
        flash("Failed to update status. Please try again.", "danger")

    return redirect(url_for("admin.feed"))
