from flask import Blueprint, render_template, redirect, url_for, flash, request
from app.forms.auth_forms import LoginForm, RegisterForm
from app.models.user import User
from app.extensions import db, login_manager
from flask_login import login_user, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from app.utils.validation import is_address_in_barangay

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")

# LOGIN
@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("resident.dashboard"))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()

        if not user:
            flash("INVALID USERNAME", "danger")
            return render_template("auth/login_clean.html", form=form)

        if not check_password_hash(user.password_hash, form.password.data):
            flash("INVALID PASSWORD", "danger")
            return render_template("auth/login_clean.html", form=form)

        login_user(user)
        flash("Login successful!", "success")

        if user.role == "admin":
            return redirect(url_for("admin.dashboard"))

        return redirect(url_for("resident.dashboard"))

    # Use a simplified standalone template to avoid layout issues
    return render_template("auth/login_clean.html", form=form)

# REGISTER
@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()

    if form.validate_on_submit():

        if not is_address_in_barangay(form.address.data):
            flash("Registration rejected — address must be within Población Barangay III.", "danger")
            return render_template("auth/register_clean.html", form=form)

        user = User(
            username=form.username.data,
            email=form.email.data,
            address=form.address.data,
            contact_number=form.contact_number.data,
            role="resident",
            password_hash=generate_password_hash(form.password.data)
        )

        db.session.add(user)
        db.session.commit()

        flash("Account created successfully!", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/register_clean.html", form=form)

# LOGOUT
@auth_bp.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("auth.login"))
