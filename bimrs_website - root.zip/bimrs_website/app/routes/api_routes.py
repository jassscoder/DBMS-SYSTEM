from flask import Blueprint, jsonify
from app.models.report import Report

api_bp = Blueprint("api", __name__, url_prefix="/api")

@api_bp.route("/reports")
def api_reports():
    reports = Report.query.all()
    data = [{
        "id": r.id,
        "title": r.title,
        "status": r.status,
        "created_at": str(r.created_at)
    } for r in reports]

    return jsonify(data)
