from flask import Blueprint, redirect, url_for
from flask_login import current_user

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """Root route: redirect authenticated users to their dashboard,
    otherwise send them to the login page."""
    if current_user.is_authenticated:
        if getattr(current_user, "role", None) == "admin":
            return redirect(url_for("admin.dashboard"))
        return redirect(url_for("resident.dashboard"))

    return redirect(url_for("auth.login"))


@main_bp.route('/debug-login')
def debug_login():
    return '<html><body><h1>DEBUG LOGIN OK</h1></body></html>'
