# app/utils/email_helpers.py

from flask_mail import Message
from flask import current_app

def send_email(subject, recipients, body, html=None):
    """
    Sends an email using Flask-Mail.
    """
    from app.extensions import mail

    msg = Message(
        subject=subject,
        recipients=recipients,
        body=body,
        html=html,
        sender=current_app.config.get("MAIL_DEFAULT_SENDER")
    )

    try:
        mail.send(msg)
        return True
    except Exception as e:
        print(f"[EMAIL ERROR] {e}")
        return False


def send_resolution_email(report):
    """
    Send a resolution notification to the reporter of a report.
    """
    if not report or not getattr(report, 'reporter', None):
        return False

    reporter = report.reporter
    subject = f"Your report '{report.title}' has been resolved"
    body = f"Hello {getattr(reporter, 'username', reporter.email)},\n\nYour report titled '{report.title}' has been marked as resolved.\n\nThank you for reporting issues in the community.\n"
    recipients = [reporter.email]

    return send_email(subject, recipients, body)
