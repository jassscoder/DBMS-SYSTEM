from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField
from wtforms.validators import DataRequired


class InfrastructureForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired()])
    category = StringField("Category", validators=[DataRequired()])
    barangay = StringField("Barangay", validators=[DataRequired()])
    status = SelectField(
        "Status",
        choices=[("Good", "Good"), ("Needs Repair", "Needs Repair"), ("Damaged", "Damaged")],
        validators=[DataRequired()]
    )
    submit = SubmitField("Save")
