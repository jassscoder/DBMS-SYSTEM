from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, FileField, SelectField, SubmitField
from wtforms.validators import DataRequired


class ReportForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired()])
    category = SelectField(
        "Category",
        choices=[("Road","Road"), ("Flooding","Flooding"), ("Garbage","Garbage"), ("Streetlight","Streetlight"), ("Other","Other")],
        validators=[DataRequired()],
    )
    description = TextAreaField("Description", validators=[DataRequired()])
    address = StringField("Address", validators=[DataRequired()])
    contact_number = StringField("Contact Number", validators=[DataRequired()])
    image = FileField("Upload Image")
    submit = SubmitField("Submit Report")


class UpdateStatusForm(FlaskForm):
    status = SelectField("Status", choices=[("PENDING","Pending"), ("IN_PROGRESS","In Progress"), ("RESOLVED","Resolved")], validators=[DataRequired()])
    submit = SubmitField("Update")
