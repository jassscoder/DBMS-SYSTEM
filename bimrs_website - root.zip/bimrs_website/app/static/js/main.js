// SIMPLE JS UTILITIES

document.addEventListener("DOMContentLoaded", () => {

    console.log("Main JS Loaded");

    // Auto-hide flash messages
    const flashes = document.querySelectorAll(".flash-message");
    if (flashes.length > 0) {
        setTimeout(() => {
            flashes.forEach(f => f.style.display = "none");
        }, 4000);
    }

});
