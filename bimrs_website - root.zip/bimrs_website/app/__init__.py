from flask import Flask
from app.extensions import db, migrate, login_manager, mail


def create_app():
    app = Flask(__name__)
    app.config.from_object("config.Config")

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    mail.init_app(app)

    # Register blueprints
    from app.routes.main_routes import main_bp
    from app.routes.auth_routes import auth_bp
    from app.routes.resident_routes import resident_bp
    from app.routes.admin_routes import admin_bp
    from app.routes.infra_routes import infra_bp
    from app.routes.report_routes import report_bp
    from app.routes.log_routes import log_bp
    from app.routes.api_routes import api_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(resident_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(infra_bp)
    app.register_blueprint(report_bp)
    app.register_blueprint(log_bp)
    app.register_blueprint(api_bp)

    return app
