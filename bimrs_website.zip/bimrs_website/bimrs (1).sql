-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2025 at 11:34 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bimrs`
--

-- --------------------------------------------------------

--
-- Table structure for table `alembic_version`
--

CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `alembic_version`
--

INSERT INTO `alembic_version` (`version_num`) VALUES
('d4e5f6g7h8i9');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `report_id` int(11) NOT NULL DEFAULT 1,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `message`, `created_at`, `report_id`, `rating`) VALUES
(1, 2, 'ok', '2025-12-12 03:20:16', 1, 5),
(2, 5, 'aba ayos', '2025-12-16 22:12:14', 8, 5),
(3, 7, 'nyenye', '2025-12-16 22:24:20', 9, 5);

-- --------------------------------------------------------

--
-- Table structure for table `infrastructure`
--

CREATE TABLE `infrastructure` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `category` varchar(80) NOT NULL,
  `barangay` varchar(120) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `infrastructure`
--

INSERT INTO `infrastructure` (`id`, `name`, `category`, `barangay`, `status`, `created_at`) VALUES
(1, 'Main Road', 'Road', 'Zone 1', 'Good', NULL),
(2, 'Kalsada', 'Road', 'Poblacion III', 'Good', '2025-12-10 01:54:06'),
(3, 'Church', 'Facility', 'Hono', 'Good', '2025-12-16 20:33:40'),
(4, 'Jollibee', 'Restaurant', 'Poblacion III', 'Good', '2025-12-16 21:17:10'),
(6, 'Mcdonalds', 'restaurant', 'Poblacion III', 'Good', '2025-12-16 21:28:57'),
(7, 'Streetlight 1', 'Lights', 'Poblacion III', 'Good', '2025-12-16 21:51:11');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `action` varchar(200) NOT NULL,
  `user_email` varchar(120) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reporter_id` int(11) NOT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `infrastructure_id` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `title`, `description`, `category`, `image_path`, `status`, `created_at`, `reporter_id`, `resolved_at`, `infrastructure_id`, `address`, `contact_number`) VALUES
(1, 'SIrang Kalsada', 'sira ang ulo', 'Road', NULL, 'RESOLVED', '2025-12-10 01:43:00', 2, '2025-12-10 01:43:36', NULL, 'Poblacion III', '09272364762'),
(2, 'Mamamo', 'AAAAA', 'Road', NULL, 'PENDING', '2025-12-11 15:18:22', 2, NULL, 2, 'Poblacion III', '00000000000'),
(3, 'aaaa', 'asdasd', 'Road', '00e52f6d7eb647c0bcc54f10c5e66ab4.jpg', 'PENDING', '2025-12-11 15:32:47', 2, NULL, 2, 'Poblacion III', '195555'),
(4, 'Test Broken Streetlight', 'Streetlight not working near the plaza.', 'Lighting', NULL, 'RESOLVED', '2025-12-12 03:53:40', 5, '2025-12-12 06:08:16', NULL, 'Población Barangay III', '09123456789'),
(5, 'Sirang Ulo', 'Sira ang ulo ng developer', 'Road', 'fb8316408424412e843118826dec961d.jpg', 'RESOLVED', '2025-12-12 09:09:54', 6, '2025-12-12 09:12:42', 1, 'Poblacion III', '09129623840'),
(8, 'Sira ang Lights', 'aaaaaa', 'Lights', '4e929ebe1ad949c69c14e49badc2e9f5.jpg', 'RESOLVED', '2025-12-16 21:52:26', 5, '2025-12-16 22:07:29', 7, 'Poblacion III', '09464407168'),
(9, 'Mcdo', 'ang mcdo', 'Restaurant', '9d7f4142ac5745d99ade64a5cbd6b7c7.png', 'RESOLVED', '2025-12-16 22:17:19', 7, '2025-12-16 22:17:46', 6, 'Poblacion III', '09129623840');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(80) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(120) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `password_hash` varchar(256) NOT NULL,
  `role` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `email`, `address`, `contact_number`, `password_hash`, `role`, `created_at`, `is_suspended`) VALUES
(1, 'admin', NULL, 'admin@example.com', '', '', 'scrypt:32768:8:1$SfOj3QcKO4FISqeZ$531b3d3d43f23790f9f3ae1019f2576e0cd973a385f348011137983e75a0564fa5973ec8528504f220da4f6be46e830a3501e4a49a0e66eca89ea7154228cfea', 'admin', NULL, 0),
(2, 'resident1', NULL, 'resident1@example.com', '123 Poblacion St.', '09171234567', 'scrypt:32768:8:1$nwO7maAMFU0IeAs0$4e6b45b25dcfad302190cdaf97fabeab71c8571c3846d25d962a25f47c896f23b13645ed8a9c8d28589658a0ce36e01645fdfc5a841ff7885c5ab8fa608a5e5e', 'resident', '2025-11-24 12:19:15', 0),
(3, 'resident2', NULL, 'resident2@example.com', '45 Market Ave.', '09177654321', 'scrypt:32768:8:1$17ZuVsC3guyXJJVP$85cd005afdf544a8b6fdc9cc181b6709bb1e3c67b9033a7497894037cb6609acd1548c83d8a47909de7f59669a04edc5ec10b61dfd068775b4a96e21a90ecd10', 'resident', '2025-11-24 12:19:15', 0),
(4, 'testuser', NULL, 'testuser@example.com', '67 Barangay Rd.', '09170001111', 'scrypt:32768:8:1$6KmYiqbrq66eXEkS$e451be1946e70b873dd06fd422ebb97704f7dccbc6c674cc7a2895f506dd5d13789ac13b3666769de955387a780c59b1054f76b3fa35787284184d1928940f4c', 'resident', '2025-11-24 12:19:15', 0),
(5, 'test_reporter', NULL, 'ivangabrielreyes6@gmail.com', NULL, NULL, 'scrypt:32768:8:1$RcTMgGF6o2jdGdBC$990776ce338dfa840c20a666aee5f9b870d8180a486e55306260be8ae230d863b1ffd7965d51cbdfb50cb85f9759c39d987433ea210aa0b59addcb4155ca3c99', 'resident', '2025-12-12 03:53:40', 0),
(6, 'alexa', 'Alexa Babao Ruben', 'alexaruben1624@gmail.com', 'Poblacion III', '09129623840', 'scrypt:32768:8:1$cixlwU9Vd1Ze88yi$441e7257499f2bbb8c6cf594e2c0033bbcfceb9fa24f88d9a6b8d73129c80883518b68a7cdae07cfcfba1a46c228dcd44f327c4215df5776e50592b8114e847d', 'resident', '2025-12-12 08:59:59', 0),
(7, 'jerome', 'Jerome Dimalaluan', 'jeromedimalaluan2411@gmail.com', 'Poblacion III', '09637336601', 'scrypt:32768:8:1$QUs2vZbEYOnEUmrw$2f0dcf87edefc8e76213564fb19b0a2ba196af6ff001f0ed09b76c3db2e21a63b5a82259dcee14f26b3f2018e38bb9d366e17cd68cc00928bbd76ee9f8d62437', 'resident', '2025-12-16 11:30:05', 0),
(8, 'ricky', 'Ricky Dolor', 'rickyfeitan16@gmail.com', 'Poblacion III', '09464407168', 'scrypt:32768:8:1$l8ipuisvcqdrDgO2$4f5e3f107dfb8463aaaad96f2192ee138e51c878a5ef48a48d8da0a2aba755a89a40b5addfe84e58ad865010f9eab7cdb1ae046c2f4d9409a8cdb329ef157e6c', 'resident', '2025-12-16 11:54:47', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alembic_version`
--
ALTER TABLE `alembic_version`
  ADD PRIMARY KEY (`version_num`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_feedback_report_id` (`report_id`);

--
-- Indexes for table `infrastructure`
--
ALTER TABLE `infrastructure`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reporter_id` (`reporter_id`),
  ADD KEY `infrastructure_id` (`infrastructure_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `infrastructure`
--
ALTER TABLE `infrastructure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_feedback_report_id` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`infrastructure_id`) REFERENCES `infrastructure` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
