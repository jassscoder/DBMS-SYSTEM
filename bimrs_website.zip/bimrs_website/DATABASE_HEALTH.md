# Database Health & Maintenance Guide

## Current Status: ✅ HEALTHY


Last checked: December 17, 2025
Version: v1.5 (Latest)

## Database Overview

**Database:** bimrs (Barangay Infrastructure Management & Reporting System)  
**Engine:** MySQL/MariaDB  
**Connection:** localhost (127.0.0.1)  
**Migration Version:** Latest (v1.5)  
**ORM:** SQLAlchemy 2.0.36  
**Framework:** Flask 3.1.2

## Tables & Record Counts

| Table | Purpose | Status |
|-------|---------|--------|
| users | User accounts, authentication, profiles | ✅ Active |
| reports | Infrastructure reports submitted by residents | ✅ Active |
| infrastructure | Infrastructure items managed by admin | ✅ Active |
| feedback | User feedback on resolved reports with ratings | ✅ Active |
| logs | Audit trail of resolved issues | ✅ Active |
| category | Normalized category lookup table (v1.5) | ✅ Active |
| barangay | Normalized barangay lookup table (v1.5) | ✅ Active |
| alembic_version | Migration tracking | ✅ Current |

## Schema Validation

### Reports Table
All required columns present and validated:
- ✅ id (Primary Key)
- ✅ title, description (Report content)
- ✅ category (String field)
- ✅ address, contact_number (Resident contact information)
- ✅ image_path (Optional image reference)
- ✅ status (PENDING, IN_PROGRESS, RESOLVED, DECLINED)
- ✅ created_at, resolved_at (Timestamp tracking)
- ✅ reporter_id (FK → users.id, Indexed)
- ✅ infrastructure_id (FK → infrastructure.id, Optional)
- ✅ Relationships: Proper ORM mappings configured

### Users Table
- ✅ username (UNIQUE, Indexed)
- ✅ email (UNIQUE, Indexed)
- ✅ password (Hashed with Werkzeug)
- ✅ address, contact_number
- ✅ is_admin (Role-based access)
- ✅ is_suspended (Account suspension status)
- ✅ created_at (Registration timestamp)
- ✅ No duplicate entries

### Feedback Table
- ✅ rating (1-5 star rating)
- ✅ message (Text feedback)
- ✅ user_id (FK → users.id)
- ✅ report_id (FK → reports.id)
- ✅ created_at (Submission timestamp)

### Foreign Key Integrity
- ✅ No orphaned references in reports.reporter_id
- ✅ No orphaned references in reports.infrastructure_id
- ✅ No orphaned references in feedback.user_id
- ✅ No orphaned references in feedback.report_id
- ✅ Cascade delete configured where appropriate

## Health Check Script

A comprehensive health check script has been created at:
```
tools/db_health_check.py
```

### Running the Health Check

```bash
# Using Python directly
python tools/db_health_check.py

# Or from venv
venv/Scripts/python.exe tools/db_health_check.py
```

### What It Checks

1. **Schema Alignment** - Ensures database tables match SQLAlchemy models
2. **Foreign Key Integrity** - Validates all FK references are valid
3. **Data Validation** - Checks for NULL values in required fields
4. **Duplicate Detection** - Finds duplicate usernames/emails
5. **Index Verification** - Confirms proper indexes exist
6. **Migration Status** - Shows current migration version

### Exit Codes

- `0` - All checks passed, database is healthy
- `1` - Issues found (see output for details)
- `2` - Cannot connect to database
- `3` - Unexpected error occurred

## Common Issues & Solutions

### Issue: Missing columns (address, contact_number)

**Symptom:** Model has fields that don't exist in database

**Solution:**
```bash
# Apply pending migrations
flask db upgrade
```

Or manually add columns:
```sql
ALTER TABLE reports ADD COLUMN address VARCHAR(255) NULL;
ALTER TABLE reports ADD COLUMN contact_number VARCHAR(50) NULL;
UPDATE alembic_version SET version_num = 'b2a23fdbd31e';
```

### Issue: Orphaned foreign key references

**Symptom:** Records reference non-existent parent records

**Prevention:**
- Always use ON DELETE CASCADE for foreign keys
- Validate data before deletion
- Use database transactions

**Fix:**
```sql
-- Find orphaned reports
SELECT * FROM reports 
WHERE reporter_id NOT IN (SELECT id FROM users);

-- Delete or reassign them
DELETE FROM reports WHERE reporter_id NOT IN (SELECT id FROM users);
```

### Issue: Duplicate usernames or emails

**Prevention:**
- Database has UNIQUE constraints
- Application validates before INSERT
- Use try-except blocks in code

**Fix:**
```sql
-- Find duplicates
SELECT email, COUNT(*) FROM users GROUP BY email HAVING COUNT(*) > 1;

-- Remove duplicates (keep first occurrence)
DELETE t1 FROM users t1
INNER JOIN users t2 
WHERE t1.id > t2.id AND t1.email = t2.email;
```

## Database Backup

### Create Backup

```bash
# Full database dump
mysqldump -u root -p bimrs > backup_$(date +%Y%m%d).sql

# Structure only
mysqldump -u root -p --no-data bimrs > schema_$(date +%Y%m%d).sql
```

### Restore Backup

```bash
mysql -u root -p bimrs < backup_20251210.sql
```

## Migration Management

### Create New Migration

```bash
# After modifying models
flask db migrate -m "description of changes"

# Review the generated migration file
# Then apply it
flask db upgrade
```

### Rollback Migration

```bash
flask db downgrade -1
```

### View Migration History

```bash
flask db history
```

## Best Practices

1. **Always run health check after migrations**
   ```bash
   flask db upgrade && python tools/db_health_check.py
   ```

2. **Backup before major changes**
   ```bash
   mysqldump -u root -p bimrs > backup_before_changes.sql
   ```

3. **Use transactions for data modifications**
   ```python
   try:
       db.session.add(new_record)
       db.session.commit()
   except:
       db.session.rollback()
       raise
   ```

4. **Validate foreign keys before deletion**
   ```python
   # Check for dependent records before deleting
   if user.reports.count() > 0:
       # Handle or prevent deletion
   ```

5. **Regular maintenance**
   - Run health check weekly
   - Review logs monthly
   - Clean up old data quarterly
   - Backup before deployments

5. **Image Management**
   - Delete old images when replacing with new ones
   - Handle missing files gracefully
   - Validate file types and sizes
   - Use secure filename generation

6. **Regular maintenance**
   - Run health check weekly
   - Review logs monthly
   - Clean up old/deleted images quarterly
   - Backup before deployments
   - Test disaster recovery procedures

## Monitoring

### Manual Checks

```sql
-- Check table sizes
SELECT 
    TABLE_NAME, 
    TABLE_ROWS, 
    ROUND(DATA_LENGTH/1024/1024, 2) AS 'Size (MB)'
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA = 'bimrs';

-- Check index usage
SHOW INDEX FROM reports;

-- Check foreign key constraints
SELECT * FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
WHERE TABLE_SCHEMA = 'bimrs' 
AND REFERENCED_TABLE_NAME IS NOT NULL;
```

## Troubleshooting

### Cannot Connect to Database

1. Check MySQL service is running:
   ```bash
   # Windows
   net start MySQL
   ```

2. Verify credentials in config.py or environment variables

3. Ensure database exists:
   ```bash
   mysql -u root -p
   SHOW DATABASES;
   ```

### Migration Conflicts

1. Check current version:
   ```bash
   flask db current
   ```

2. If stuck, manually set version:
   ```sql
   UPDATE alembic_version SET version_num = 'target_version';
   ```

3. Or reset and reapply:
   ```bash
   # Backup first!
   flask db stamp head
   ```

## Contact & Support

## Recent Improvements (v1.5)

### Fixed Issues
- ✅ Report model missing infrastructure relationship - **FIXED**
- ✅ Form category dropdown not populating - **FIXED**
- ✅ Edit report form not pre-filling data - **FIXED**
- ✅ Image removal not working properly - **FIXED**
- ✅ Feedback modal JavaScript conflicts - **FIXED**
- ✅ Double variable declarations causing console errors - **FIXED**

### Enhancements
- ✅ Image upload UI with clear/remove buttons
- ✅ Current image preview in edit forms
- ✅ Confirmation modals for destructive actions
- ✅ Better error handling and logging
- ✅ Auto-initialization for modal functions
- ✅ Guard checks to prevent double initialization

## Troubleshooting v1.5 Specific Issues

### Issue: Feedback modal not opening
**Solution:** Clear browser cache and reload the page. The script uses auto-initialization on DOM ready.

### Issue: Images not displaying in edit form
**Solution:** Ensure image files exist in `/static/uploads/` directory. Check file permissions.

### Issue: Edit report form shows empty fields
**Solution:** Verify database relationships are properly configured. Run health check script.

## Contact & Support

For database issues:
1. Run health check script for diagnostics: `python tools/db_health_check.py`
2. Check console for JavaScript errors (F12 in browser)
3. Review application logs in `/logs/` directory
4. Check database connectivity and migrations
5. Contact system administrator if issues persist

---

**Last Updated:** December 17, 2025  
**Version:** v1.5  
**Maintained By:** Development Team  
**Status:** Production Ready  
**Next Review:** Weekly
