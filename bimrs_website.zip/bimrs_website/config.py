import os

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY") or "super-secret-key"

    # ===== MySQL DATABASE URI =====
    DB_USER = os.environ.get("DB_USER", "root")
    DB_PASS = os.environ.get("DB_PASS", "")
    DB_HOST = os.environ.get("DB_HOST", "127.0.0.1")
    DB_NAME = os.environ.get("DB_NAME", "bimrs")


    # Prefer explicit DATABASE_URL if provided; otherwise build a MySQL URI
    # Use PyMySQL driver on Windows if available. Allow override with DATABASE_URL.
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL") or (
        f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}/{DB_NAME}?charset=utf8mb4"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Connection pool settings to prevent timeout issues
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 10,
        'pool_recycle': 3600,  # Recycle connections after 1 hour
        'pool_pre_ping': True,  # Verify connections before using them
        'pool_timeout': 30,
        'max_overflow': 20
    }

    # ===== EMAIL SETTINGS =====
    MAIL_SERVER = "smtp.gmail.com"
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD")
    MAIL_DEFAULT_SENDER = os.environ.get("MAIL_DEFAULT_SENDER") or os.environ.get("MAIL_USERNAME")
    
    # Validate email configuration
    if not MAIL_USERNAME or not MAIL_PASSWORD:
        import warnings
        warnings.warn(
            "Email configuration missing! Set MAIL_USERNAME and MAIL_PASSWORD environment variables. "
            "Email notifications will not work without proper configuration.",
            UserWarning
        )

    # UPLOAD PATH
    # Use a path relative to this project file so it's consistent regardless of working dir.
    # Files will be saved under app/static/uploads and served via Flask's static route.
    BASE_DIR = os.path.dirname(__file__)
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "app", "static", "uploads")
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB

    # HERO IMAGE DIRECTORY
    # Set this to your image directory path (relative to static folder or absolute path)
    # Example: "static/mock_images/hero.jpg" or "/path/to/your/image.jpg"
    HERO_IMAGE_DIRECTORY = os.environ.get("HERO_IMAGE_DIRECTORY") or "static/mock_images/hero.jpg"
    HERO_VIDEO_URL = os.environ.get("HERO_VIDEO_URL") or ""  # Optional video URL


