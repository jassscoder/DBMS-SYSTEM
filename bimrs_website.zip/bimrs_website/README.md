# Barangay Infrastructure Maintenance Request System (BIMRS)

A comprehensive Flask web application for **Población Barangay III** that enables residents to report infrastructure issues and allows administrators to manage, track, and resolve reports efficiently.

---

## 🚀 Features

### Resident Features
- **User Registration & Authentication**
  - Secure account creation with email and password
  - Address validation (restricted to Población Barangay III residents)
  - Contact number registration
  - User login/logout with session management
  - Account suspension detection and prevention
  
- **Submit Infrastructure Reports**
  - Create detailed reports with title, category, and description
  - Image uploads with validation (16MB max, automatic file naming)
  - Location/address information with barangay validation
  - Contact details (phone number)
  - Optional infrastructure linking (select from existing infrastructure items)
  - Automatic PENDING status assignment upon submission
  
- **Personal Dashboard**
  - View all submitted reports in one place
  - Real-time status tracking (PENDING, IN_PROGRESS, RESOLVED, DECLINED)
  - Access to individual report details
  - Quick navigation to report submission and feedback pages
  
- **Track Report Status**
  - View all personal reports with timestamps
  - Status indicators with visual feedback
  - Report creation and resolution dates
  - Detailed view of each report with all information
  
- **Email Notifications**
  - Automatic email alerts when report status changes
  - Notifications for: PENDING → IN_PROGRESS → RESOLVED transitions
  - Custom email templates with report details
  - Sender: noreplybimrs@gmail.com
  
- **Feedback System**
  - Submit feedback on resolved reports
  - Rate reports with 1-5 star rating system
  - Write detailed feedback messages
  - View existing feedback on reports
  - Linked to user accounts for accountability
  
- **Contact Form**
  - Direct messaging to barangay administrators
  - Fields: name, email, subject, and message
  - Email delivery to admin inbox
  - AJAX-based submission with real-time validation

### Admin Features
- **Dashboard Analytics**
  - Visual summary cards with key metrics:
    - Total reports count
    - Pending reports count
    - In-progress reports count
    - Resolved reports count
    - Total infrastructure items count
  - Quick navigation to all admin sections
  - Real-time data from database
  
- **Report Management (Facebook-Style Feed)**
  - View all reports in chronological order (newest first)
  - Filter reports by status:
    - All reports
    - PENDING (awaiting review)
    - IN_PROGRESS (being worked on)
    - RESOLVED (completed)
  - Detailed report cards showing:
    - Reporter information (username, email)
    - Report title, category, description
    - Image preview
    - Address and contact number
    - Creation timestamp
    - Linked infrastructure (if any)
  - Status update functionality with dropdown
  - Automatic email notifications sent to reporters on status change
  - Report deletion for DECLINED submissions (including image cleanup)
  - Modal-based detail view with full report information
  
- **Infrastructure Management**
  - Full CRUD operations for infrastructure items
  - Add new infrastructure with:
    - Name
    - Category (Roads, Bridges, Buildings, etc.)
    - Barangay assignment
    - Status (Good, Under Repair, Needs Attention, etc.)
  - View all infrastructure items in sortable table
  - Edit and delete existing infrastructure
  - Link infrastructure to reports for better tracking
  
- **User Management**
  - View all resident accounts (excludes admins)
  - User list with details:
    - Username and email
    - Address and contact number
    - Account creation date
    - Suspension status
    - Total reports submitted
  - Suspend/unsuspend user accounts
  - User detail modal with complete information
  - Track user activity and report history
  
- **Feedback Review**
  - Monitor all feedback submitted by residents
  - View feedback with:
    - User information
    - Associated report
    - Star rating (1-5)
    - Feedback message
    - Submission timestamp
  - Track resident satisfaction
  - Review feedback on resolved issues
  
- **Resolved Logs (Audit Trail)**
  - Comprehensive audit of all resolved issues
  - View resolved reports with resolution timestamps
  - Track completion rate and timeframes
  - Historical data for performance analysis
  - Ordered by resolution date (newest first)
  
- **API Endpoints**
  - RESTful API for reports (`/api/reports`)
  - JSON response with report data
  - Programmatic access to report information

### Public Pages
- **Homepage**
  - Hero section with configurable image/video
  - Recent resolved projects showcase (last 3 projects)
  - Automatic redirect for authenticated users to their dashboard
  - Modern, responsive design with glassmorphic elements
  
- **Services Page**
  - Information about barangay services
  - Service descriptions and offerings
  
- **Portfolio Page**
  - Showcase of completed projects (last 6 resolved reports)
  - Visual gallery of infrastructure improvements
  - Before/after documentation
  
- **About Us Page**
  - Barangay information
  - Mission and vision statements
  - Contact information
  
- **Contact Page**
  - Contact form for inquiries
  - AJAX-based form submission
  - Email delivery to admin
  - Success/error feedback

### Technical Features
- **Database**
  - MySQL database with PyMySQL driver
  - SQLAlchemy ORM for database operations
  - Foreign key relationships between models
  - Automatic timestamp tracking (created_at, resolved_at)
  
- **Image Processing**
  - Pillow-based image validation
  - File type validation (JPEG, PNG, GIF, BMP)
  - File size limit (16MB max)
  - Secure filename generation with UUID
  - Automatic upload folder management
  - Image cleanup on report deletion
  
- **Email Integration**
  - Flask-Mail with Gmail SMTP
  - HTML and plain text email support
  - Automatic notifications for:
    - Report status changes
    - New report submissions
    - Contact form submissions
  - Template-based email generation
  - Error handling and fallback mechanisms
  
- **Database Migrations**
  - Flask-Migrate with Alembic
  - Version-controlled schema changes
  - Migration scripts for:
    - Initial schema setup
    - Infrastructure foreign key addition
    - Report contact fields
    - User suspension feature
    - Feedback model with ratings
  
- **Form Validation**
  - WTForms for server-side validation
  - Custom validators for:
    - Address validation (Población Barangay III only)
    - Email format validation
    - Contact number validation
    - Required field validation
  - CSRF protection on all forms
  - Flash messages for user feedback
  
- **Responsive UI**
  - Modern dark theme with glassmorphic design elements
  - Bootstrap-based responsive layout
  - Mobile-friendly navigation
  - Interactive components (modals, dropdowns, cards)
  - Custom CSS styling
  - JavaScript for dynamic interactions
  
- **Security Features**
  - Flask-Login for authentication and session management
  - Password hashing with Werkzeug
  - CSRF protection with Flask-WTF
  - Login required decorators for protected routes
  - Role-based access control (admin vs resident)
  - Account suspension functionality
  - Secure file upload validation
  - SQL injection prevention via ORM
  
- **Address Validation**
  - Geographic validation for Población Barangay III
  - Checks for valid street names and locations
  - Prevents reports from outside the barangay
  - Custom validation helpers
  
- **Error Handling**
  - Database error handling with rollbacks
  - File upload error management
  - Email sending error recovery
  - User-friendly error messages
  - Logging for debugging
  
- **Development Tools**
  - Multiple testing scripts in `tools/` directory
  - Database health check utilities
  - Email sending tests
  - Image upload testing
  - Login testing utilities
  - Direct database access tools
  - Seed data generation scripts

---

## 🔄 Recent Updates (v1.5)

### Core Features Completed
- **Suspended Accounts Cannot Login**: Enforced at the authentication layer via `User.is_active()` so suspended users are treated as inactive by Flask-Login.
- **Infrastructure Edit/Update UI**: Admin table now includes Edit/Delete actions with a modal editor; updates and deletes are handled via `/infrastructure/<id>/update` and `/infrastructure/<id>/delete` (safe delete blocks when linked to reports).
- **Resident Report Editing**: Residents can edit their own reports while status is `PENDING`. An Edit button appears in the dashboard cards and opens the edit form with pre-filled values. Image replacement is supported.
- **Email Delivery Verified**: Reporter status-change emails are sent to the reporter's email only; Contact Us form delivers to admin inbox.

### UI/UX Improvements (Latest)
- **Enhanced Image Upload**: Added clear/remove buttons (✕) for selected images in both Submit and Edit Report forms
- **Edit Report Image Handling**: Shows preview of current image with remove button, confirmation modal when removing images, ability to replace or keep existing images
- **Feedback Form Modal**: Fixed global scope issues with feedback functions, auto-initialization on page load, robust error handling with detailed logging
- **Model Relationships**: Added `infrastructure` relationship to Report model for proper ORM access
- **Form Data Population**: Dynamic category and infrastructure dropdowns that populate from database

## ✅ Verification Checklist

### Functional Tests Completed
- ✅ User registration with address validation
- ✅ Report submission with category and infrastructure selection
- ✅ Report editing with image management (preview, replace, remove)
- ✅ Admin status update with email notifications
- ✅ Feedback submission with star ratings
- ✅ Infrastructure CRUD operations
- ✅ User suspension/unsuspension
- ✅ Contact form submissions
- ✅ Image upload with validation
- ✅ Database relationships and migrations

### Known Working Features
- Report detail modal display with all fields
- Feedback modal with form validation
- Image file selection with clear button
- Current image preview in edit form
- Confirmation dialogs for destructive actions
- Flash messages for user feedback
- Proper error handling and logging
- Session management and authentication

### Database Status
- Migration v1.5: Latest version applied
- All tables created with proper relationships
- Foreign keys validated and working
- Sample data available for testing



