from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo
from app.forms.custom_validators import validate_email_with_at, validate_contact_number_11_digits


class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(min=2, max=50)])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")


class RegisterForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(min=2, max=50)])
    name = StringField("Full Name", validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField("Email (Required)", validators=[
        DataRequired(message="Email is required"),
        Email(message="Please enter a valid email address"),
        validate_email_with_at
    ])
    address = StringField("Address", validators=[DataRequired(), Length(min=5, max=200)])
    contact_number = StringField("Contact Number", validators=[DataRequired(), validate_contact_number_11_digits])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField(
        "Confirm Password",
        validators=[DataRequired(), EqualTo("password", message="Passwords must match.")],
    )
    submit = SubmitField("Register")
