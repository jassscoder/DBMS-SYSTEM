"""Custom validators for forms."""
from wtforms.validators import ValidationError
import re


def validate_email_with_at(form, field):
    """Validator to ensure email contains @ symbol."""
    if field.data and '@' not in field.data:
        raise ValidationError('Email must contain @ symbol.')


def validate_contact_number_11_digits(form, field):
    """Validator to ensure contact number is exactly 11 digits."""
    if field.data:
        # Remove any spaces or special characters and check if only digits remain
        digits_only = re.sub(r'\D', '', field.data)
        if len(digits_only) != 11:
            raise ValidationError('Contact number must be exactly 11 digits.')


def validate_poblacion_address(form, field):
    """Validator to ensure address is within Poblacion III."""
    if field.data:
        address_lower = field.data.lower()
        # Check for various formats of Poblacion III
        valid_patterns = [
            'poblacion iii',
            'poblacion 3',
            'poblacion three',
            'pob. iii',
            'pob iii',
            'pob. 3',
            'pob 3'
        ]
        if not any(pattern in address_lower for pattern in valid_patterns):
            raise ValidationError('Address must be within Poblacion III (Población Barangay III).')
