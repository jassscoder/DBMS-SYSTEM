from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField
from wtforms.validators import DataRequired, ValidationError


class InfrastructureForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired()])
    category = StringField("Category", validators=[DataRequired()])
    barangay = StringField("Barangay", default="Poblacion III", render_kw={"value": "Poblacion III", "readonly": True})
    status = SelectField(
        "Status",
        choices=[("Good", "Good"), ("Needs Repair", "Needs Repair"), ("Damaged", "Damaged")],
        validators=[DataRequired()]
    )
    submit = SubmitField("Save")

    def validate_category(self, field):
        # Category validation - just check it's not empty
        if not field.data or not field.data.strip():
            raise ValidationError("Category is required.")

