from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Optional
from app.forms.custom_validators import validate_contact_number_11_digits, validate_poblacion_address


class ReportForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired()])
    category = SelectField("Category", validators=[DataRequired()])
    infrastructure = SelectField(
        "Choose Infrastructure",
        coerce=int,
        validators=[DataRequired()]
    )
    description = TextAreaField("Description", validators=[DataRequired()])
    address = StringField("Address", validators=[DataRequired(), validate_poblacion_address])
    contact_number = StringField("Contact Number", validators=[DataRequired(), validate_contact_number_11_digits])
    image = FileField("Upload Image (Optional)", validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'gif'], 'Images only (jpg, jpeg, png, gif)')
    ])
    submit = SubmitField("Submit Report")

    def __init__(self, *args, **kwargs):
        super(ReportForm, self).__init__(*args, **kwargs)
        
        # Dynamically populate category choices from database (case-insensitive deduplication)
        from app.models.infrastructure import Infrastructure
        from sqlalchemy import func
        
        # Get unique categories (case-insensitive)
        categories = Infrastructure.query.with_entities(Infrastructure.category).distinct().all()
        unique_categories = {}
        for (cat,) in categories:
            cat_lower = cat.lower()
            if cat_lower not in unique_categories:
                unique_categories[cat_lower] = cat
        
        # Sort and create choices
        sorted_categories = sorted(unique_categories.values(), key=str.lower)
        self.category.choices = [(cat, cat) for cat in sorted_categories]
        
        # Populate all infrastructure choices (needed for validation)
        # JavaScript will filter the display based on selected category
        infrastructures = Infrastructure.query.order_by(Infrastructure.name).all()
        self.infrastructure.choices = [(i.id, f"{i.name}") for i in infrastructures]

class UpdateStatusForm(FlaskForm):
    status = SelectField("Status", choices=[("PENDING","Pending"), ("IN_PROGRESS","In Progress"), ("RESOLVED","Resolved"), ("DECLINED","Declined")], validators=[DataRequired()])
    submit = SubmitField("Update")