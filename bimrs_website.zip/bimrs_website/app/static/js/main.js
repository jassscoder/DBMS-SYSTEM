// SIMPLE JS UTILITIES

// Hide page loader when page is fully loaded
window.addEventListener('load', () => {
    const loader = document.getElementById('pageLoader');
    if (loader) {
        loader.classList.add('hidden');
        // Remove from DOM after transition
        setTimeout(() => {
            loader.style.display = 'none';
        }, 500);
    }
});

document.addEventListener("DOMContentLoaded", () => {

    console.log("Main JS Loaded");

    // Auto-hide flash messages
    const flashes = document.querySelectorAll(".flash-message");
    if (flashes.length > 0) {
        setTimeout(() => {
            flashes.forEach(f => f.style.display = "none");
        }, 4000);
    }

    // Initial nav indicator position
    syncNavActiveState();
    window.addEventListener('resize', () => updateNavIndicator());

    // Glide indicator immediately on nav clicks (before navigation/PJAX swap)
    document.addEventListener('click', (event) => {
        const navLink = event.target.closest('.nav-menu a');
        if (!navLink) return;
        updateNavIndicator(navLink);
        // Also update active classes immediately so visual state matches click
        const navMenu = document.querySelector('.nav-menu');
        if (navMenu) {
            navMenu.querySelectorAll('a').forEach(a => a.classList.remove('active'));
            navLink.classList.add('active');
        }
        // Also pre-emptively sync using target href so the bar doesn't lag
        syncNavActiveState(navLink.href);
    });

});

/* Background slideshow support
   Usage: add a <div class="bg-slideshow" data-images="/static/..,/static/..."></div>
   Images should be comma-separated URLs. Slideshow will crossfade every 7 seconds.
*/
function initBgSlideshows() {
    const slideshows = document.querySelectorAll('.bg-slideshow');
    slideshows.forEach(slideshow => {
        const data = slideshow.getAttribute('data-images') || '';
        const images = data.split(',').map(s => s.trim()).filter(Boolean);
        if (images.length === 0) return;

        // Preload all images up-front to avoid flicker
        const cache = new Map();
        function preload(src) {
            if (cache.has(src)) return cache.get(src);
            const p = new Promise((resolve, reject) => {
                const img = new Image();
                img.onload = () => resolve(src);
                img.onerror = reject;
                img.src = src;
            });
            cache.set(src, p);
            return p;
        }
        images.forEach(preload);

        // create two slide layers for crossfade
        const layerA = document.createElement('div');
        const layerB = document.createElement('div');
        layerA.className = 'bg-slide';
        layerB.className = 'bg-slide';
        slideshow.appendChild(layerA);
        slideshow.appendChild(layerB);

        let currentIndex = 0;
        let visible = layerA;
        let hidden = layerB;

        // Set initial image (after preload to ensure smooth first paint)
        preload(images[0]).then(() => {
            visible.style.backgroundImage = `url('${images[0]}')`;
            // Use faster initial transition, then remove it
            visible.classList.add('initial');
            // next frame: show
            requestAnimationFrame(() => {
                visible.classList.add('visible');
                // remove the initial class shortly after to restore normal transitions
                setTimeout(() => {
                    visible.classList.remove('initial');
                }, 700);
            });
        });

        if (images.length <= 1) return; // No slideshow needed for single image

        // Prepare next image on hidden layer
        const setHiddenToIndex = (idx) => {
            preload(images[idx]).then(() => {
                hidden.style.backgroundImage = `url('${images[idx]}')`;
            }).catch(() => {
                hidden.style.backgroundImage = `url('${images[idx]}')`;
            });
        };
        setHiddenToIndex(1);

        const intervalMs = 7000;
        const tick = () => {
            currentIndex = (currentIndex + 1) % images.length;

            // Crossfade using class toggles; ensure browser batches style changes
            requestAnimationFrame(() => {
                hidden.classList.add('visible');
                visible.classList.remove('visible');

                // Swap references
                const tmp = visible;
                visible = hidden;
                hidden = tmp;

                // Preload and set the next image into now-hidden layer
                const nextIndex = (currentIndex + 1) % images.length;
                setHiddenToIndex(nextIndex);
            });
        };

        // Start cycle after first paint; no extra long initial fade
        setTimeout(() => {
            tick();
            setInterval(tick, intervalMs);
        }, intervalMs);
    });
}

document.addEventListener('DOMContentLoaded', initBgSlideshows);

// Animated navbar indicator that slides to the active link
function updateNavIndicator(targetLink = null) {
    const navMenu = document.querySelector('.nav-menu');
    const indicator = document.getElementById('navActiveIndicator');
    if (!navMenu || !indicator) return;

    const activeLink = targetLink || navMenu.querySelector('a.active');
    if (!activeLink) {
        indicator.style.setProperty('--nav-indicator-width', '0px');
        indicator.style.setProperty('--nav-indicator-opacity', '0');
        return;
    }

    const menuRect = navMenu.getBoundingClientRect();
    const linkRect = activeLink.getBoundingClientRect();
    const left = linkRect.left - menuRect.left;
    const width = linkRect.width;

    indicator.style.setProperty('--nav-indicator-left', `${left}px`);
    indicator.style.setProperty('--nav-indicator-width', `${width}px`);
    indicator.style.setProperty('--nav-indicator-opacity', '1');
}

// Sync active class on navbar links based on current location (needed because navbar is outside PJAX root)
function syncNavActiveState(urlOverride = null) {
    const navMenu = document.querySelector('.nav-menu');
    if (!navMenu) return;

    const links = Array.from(navMenu.querySelectorAll('a'));
    links.forEach(link => link.classList.remove('active'));

    const href = urlOverride || window.location.href;
    const currentPath = new URL(href, window.location.origin).pathname;
    // Prefer exact match first
    let best = links.find(l => new URL(l.href, window.location.origin).pathname === currentPath);
    if (!best) {
        // Fallback: startsWith (for trailing slashes)
        best = links.find(l => currentPath.startsWith(new URL(l.href, window.location.origin).pathname));
    }
    if (best) {
        best.classList.add('active');
    }

    updateNavIndicator(best || null);
}

// Show loader for report card status updates
function showCardLoader(form) {
    // Create and show a simple loader on the form
    const existingLoader = form.querySelector('.inline-loader');
    if (!existingLoader) {
        const loader = document.createElement('div');
        loader.className = 'inline-loader';
        loader.innerHTML = '<div class="inline-spinner"></div><span>Updating...</span>';
        loader.style.cssText = 'display: inline-flex; align-items: center; gap: 8px; margin-left: 10px; color: var(--accent-yellow); font-size: 0.9rem; font-weight: 600;';
        form.appendChild(loader);
    }
}

// Lightweight PJAX navigation to keep background video playing
function enablePjaxNavigation() {
    let lastClickX = window.innerWidth / 2; // default center
    const isSameOrigin = (url) => {
        try {
            const u = new URL(url, window.location.origin);
            return u.origin === window.location.origin;
        } catch {
            return false;
        }
    };

    // Auth pages need the full layout (body/html classes, navbar visibility),
    // so bypass PJAX for them to avoid stale shells when navigating back.
    const shouldBypassPjax = (url) => {
        try {
            const u = new URL(url, window.location.origin);
            const path = u.pathname;
            return ['/login', '/register'].some(p => path.startsWith(p));
        } catch {
            return true;
        }
    };

    const pjaxRoot = document.getElementById('pjax-root');
    if (!pjaxRoot) return;

    let animTarget = pjaxRoot.querySelector('.main-content') || pjaxRoot;

    const setAnimTarget = () => {
        animTarget = pjaxRoot.querySelector('.main-content') || pjaxRoot;
    };

    const clearAnimClasses = () => {
        ['pjax-out-left', 'pjax-out-right', 'pjax-in-left', 'pjax-in-right', 'pjax-transitioning'].forEach(cls => animTarget.classList.remove(cls));
    };

    const playOut = (direction) => {
        clearAnimClasses();
        animTarget.classList.add('pjax-transitioning');
        if (direction === 'right') {
            animTarget.classList.add('pjax-out-right');
        } else {
            animTarget.classList.add('pjax-out-left');
        }
    };

    const playIn = (direction) => {
        clearAnimClasses();
        animTarget.classList.add('pjax-transitioning');
        if (direction === 'right') {
            animTarget.classList.add('pjax-in-right');
        } else {
            animTarget.classList.add('pjax-in-left');
        }
        // clean up after animation completes
        setTimeout(clearAnimClasses, 360);
    };

    const runInlineScripts = (container) => {
        const scripts = container.querySelectorAll('script');
        scripts.forEach((oldScript) => {
            const newScript = document.createElement('script');
            if (oldScript.src) {
                newScript.src = oldScript.src;
            } else {
                newScript.textContent = oldScript.textContent;
            }
            document.head.appendChild(newScript);
            // Remove after execution to avoid clutter
            setTimeout(() => newScript.remove(), 0);
        });
    };

    async function navigateTo(url, push = true, directionHint = null) {
        const dir = 'left'; // force slide-left for clearer visibility
            const outDir = 'left';
            const inDir = 'right';
            playOut(outDir);
        try {
            const res = await fetch(url, {
                headers: { 'X-PJAX': 'true' },
                credentials: 'same-origin' // ensure auth cookies are sent (e.g., logout)
            });
            const html = await res.text();
            const doc = new DOMParser().parseFromString(html, 'text/html');
            const nextRoot = doc.getElementById('pjax-root');
            if (!nextRoot) {
                // Fallback to full navigation if target page doesn't support PJAX
                window.location.href = url;
                return;
            }
            // Replace content
            pjaxRoot.innerHTML = nextRoot.innerHTML;
            setAnimTarget();
            // Execute any inline scripts inside the new content so page-level handlers (e.g., modals) rebind
            runInlineScripts(pjaxRoot);
            // Animate the new content in the opposite direction for a subtle swipe effect
                playIn(inDir);
            // Update title
            const nextTitle = doc.querySelector('title');
            if (nextTitle) document.title = nextTitle.textContent;
            // Update history
            const finalUrl = res.url || url;
            if (push) window.history.pushState({ pjax: true, url: finalUrl }, '', finalUrl);
            // After history is updated, sync nav active state to the new URL
            syncNavActiveState(finalUrl);
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'instant' });
        } catch (e) {
            console.error('PJAX navigation failed, falling back:', e);
            window.location.href = url;
        }
    }

    // Intercept link clicks for same-origin navigation
    document.addEventListener('click', (event) => {
        const link = event.target.closest('a');
        if (!link) return;
        if (link.hasAttribute('data-no-pjax')) return;
        if (link.target && link.target !== '_self') return;
        const href = link.getAttribute('href');
        if (!href || href.startsWith('#')) return;
        if (href.startsWith('mailto:') || href.startsWith('tel:')) return;

        // Always perform full navigation for logout endpoints so session clears reliably
        const path = new URL(link.href, window.location.origin).pathname;
        if (path.includes('/logout')) return;

    const url = link.href;
        if (!isSameOrigin(url)) return;
        if (url === window.location.href) return;
    if (shouldBypassPjax(url)) return; // allow normal navigation for auth pages

        event.preventDefault();
        navigateTo(url, true);
    });

    // Handle browser back/forward buttons
    window.addEventListener('popstate', (event) => {
        if (event.state && event.state.pjax && event.state.url) {
            if (shouldBypassPjax(event.state.url)) {
                window.location.href = event.state.url;
                return;
            }
            // Update URL-derived nav state before content swap finishes
            syncNavActiveState();
            navigateTo(event.state.url, false);
        }
    });

    // Seed initial history state for consistent PJAX navigation
    window.history.replaceState({ pjax: true, url: window.location.href }, '', window.location.href);
    syncNavActiveState();
}

document.addEventListener('DOMContentLoaded', enablePjaxNavigation);