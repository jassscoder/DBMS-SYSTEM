from datetime import datetime
from ..extensions import db


class Barangay(db.Model):
    __tablename__ = "barangay"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    infrastructures = db.relationship("Infrastructure", backref="barangay_ref", lazy=True)

    def __repr__(self):
        return f"<Barangay {self.name}>"
