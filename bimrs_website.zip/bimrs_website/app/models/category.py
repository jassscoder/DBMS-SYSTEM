from datetime import datetime
from ..extensions import db


class Category(db.Model):
    __tablename__ = "category"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False, unique=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    infrastructures = db.relationship("Infrastructure", backref="category_ref", lazy=True)
    reports = db.relationship("Report", backref="category_ref", lazy=True)

    def __repr__(self):
        return f"<Category {self.name}>"
