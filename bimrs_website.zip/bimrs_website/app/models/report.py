from datetime import datetime
from ..extensions import db

class Report(db.Model):
    __tablename__ = "reports"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(255))
    contact_number = db.Column(db.String(50))
    image_path = db.Column(db.String(255))
    status = db.Column(db.String(50), default="PENDING")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # FK → users.id (reporter)
    reporter_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    # Optional link to an infrastructure item
    infrastructure_id = db.Column(db.Integer, db.ForeignKey("infrastructure.id"), nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)

    # Relationships
    reporter = db.relationship("User", back_populates="reports")
    infrastructure = db.relationship("Infrastructure", backref="reports")

    def __repr__(self):
        return f"<Report {self.title}>"
