from datetime import datetime
from ..extensions import db


class Infrastructure(db.Model):
    __tablename__ = "infrastructure"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(120), nullable=False)
    barangay = db.Column(db.String(120), default="Poblacion III", nullable=False)
    status = db.Column(db.String(50), default="Good")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Infrastructure {self.name}>"
