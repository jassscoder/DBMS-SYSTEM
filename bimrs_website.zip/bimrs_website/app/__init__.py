from flask import Flask
from app.extensions import db, migrate, login_manager, mail
import os
import logging
from logging.handlers import RotatingFileHandler


def create_app():
    app = Flask(__name__)
    app.config.from_object("config.Config")

    # Configure logging
    if not app.debug and not app.testing:
        # Create logs directory if it doesn't exist
        if not os.path.exists('logs'):
            os.mkdir('logs')
        
        # File handler with rotation (10MB max, keep 10 backup files)
        file_handler = RotatingFileHandler('logs/bimrs.log', maxBytes=10240000, backupCount=10)
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
        ))
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
        
        app.logger.setLevel(logging.INFO)
        app.logger.info('BIMRS startup')
    
    # Also configure root logger for other modules
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),  # Console output
            logging.FileHandler('logs/bimrs.log') if os.path.exists('logs') or os.makedirs('logs', exist_ok=True) else logging.StreamHandler()
        ]
    )

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    mail.init_app(app)

    # Ensure upload folder exists so file.save(...) won't raise FileNotFoundError
    upload_folder = app.config.get("UPLOAD_FOLDER")
    if upload_folder:
        try:
            os.makedirs(upload_folder, exist_ok=True)
        except Exception:
            # If folder cannot be created, log but continue — saving will fail later with clear error
            app.logger.exception("Failed to create upload folder: %s", upload_folder)

    # Register blueprints
    from app.routes.main_routes import main_bp
    from app.routes.auth_routes import auth_bp
    from app.routes.resident_routes import resident_bp
    from app.routes.admin_routes import admin_bp
    from app.routes.infra_routes import infra_bp
    from app.routes.report_routes import report_bp
    from app.routes.log_routes import log_bp
    from app.routes.api_routes import api_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(resident_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(infra_bp)
    app.register_blueprint(report_bp)
    app.register_blueprint(log_bp)
    app.register_blueprint(api_bp)

    return app
