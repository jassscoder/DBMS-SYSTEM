from flask import Blueprint, render_template, redirect, url_for, flash, request
from app.forms.auth_forms import LoginForm, RegisterForm
from app.models.user import User
from app.extensions import db, login_manager
from flask_login import login_user, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from app.utils.validation import is_address_in_barangay

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")

# LOGIN
@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("resident.dashboard"))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()

        if not user:
            flash("Account not found. Please create an account first.", "danger")
            return render_template("auth/login_clean.html", form=form)

        if not check_password_hash(user.password_hash, form.password.data):
            flash("Invalid username or password.", "danger")
            return render_template("auth/login_clean.html", form=form)

        # Block suspended accounts even if credentials are correct
        if user.is_suspended:
            flash("Your account has been suspended. Please contact the administrator.", "danger")
            return render_template("auth/login_clean.html", form=form)

        # Flask-Login automatically checks is_active() before allowing login
        # If account is suspended, is_active() returns False and login_user fails
        if not login_user(user):
            flash("Your account has been suspended. Please contact the administrator.", "danger")
            return render_template("auth/login_clean.html", form=form)

        flash("Login successful!", "success")

        if user.role == "admin":
            return redirect(url_for("admin.dashboard"))

        return redirect(url_for("resident.dashboard"))

    # Use a simplified standalone template to avoid layout issues
    return render_template("auth/login_clean.html", form=form)

# REGISTER
@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()

    if form.validate_on_submit():

        if not is_address_in_barangay(form.address.data):
            flash("Registration rejected — address must be within Población Barangay III.", "danger")
            return render_template("auth/register_clean.html", form=form)

        # Check if username already exists
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash("Username already exists. Please choose a different one.", "danger")
            return render_template("auth/register_clean.html", form=form)
        
        # Check if email already exists
        existing_email = User.query.filter_by(email=form.email.data).first()
        if existing_email:
            flash("Email already registered. Please use a different email.", "danger")
            return render_template("auth/register_clean.html", form=form)

        user = User(
            username=form.username.data,
            name=form.name.data,
            email=form.email.data,
            address=form.address.data,
            contact_number=form.contact_number.data,
            role="resident",
            password_hash=generate_password_hash(form.password.data)
        )

        db.session.add(user)
        db.session.commit()

        flash("Account created successfully! Please check your email for confirmation.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/register_clean.html", form=form)

# LOGOUT
@auth_bp.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("main.index"))
