from flask import Blueprint, render_template, jsonify, request
from flask_login import login_required, current_user
from app.models.report import Report
from app.models.feedback import Feedback
from app.extensions import db

resident_bp = Blueprint("resident", __name__, url_prefix="/resident")

@resident_bp.route("/dashboard")
@login_required
def dashboard():
    # Defensive DB access: if DB isn't initialized, show an empty list instead of failing
    try:
        my_reports = Report.query.filter_by(reporter_id=current_user.id).order_by(Report.created_at.desc()).all()
    except Exception:
        my_reports = []

    return render_template("resident/my_reports.html", reports=my_reports)

@resident_bp.route("/feedback")
@login_required
def feedback_page():
    # Get all resolved reports for the current user
    try:
        resolved_reports = Report.query.filter_by(
            reporter_id=current_user.id,
            status='RESOLVED'
        ).order_by(Report.resolved_at.desc()).all()
    except Exception:
        resolved_reports = []
    
    return render_template("resident/feedback.html", reports=resolved_reports)

@resident_bp.route("/reports/<int:report_id>")
@login_required
def report_detail(report_id):
    report = Report.query.get_or_404(report_id)
    
    # Ensure the report belongs to the current user
    if report.reporter_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    try:
        return jsonify({
            'id': report.id,
            'title': report.title,
            'category': report.category,
            'status': report.status,
            'description': report.description,
            'address': report.address,
            'contact_number': report.contact_number,
            'image_path': report.image_path,
            'infrastructure': report.infrastructure.name if report.infrastructure else 'N/A',
            'created_at': report.created_at.strftime('%B %d, %Y at %I:%M %p') if report.created_at else 'N/A',
            'resolved_at': report.resolved_at.strftime('%B %d, %Y at %I:%M %p') if report.resolved_at else 'N/A'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@resident_bp.route("/feedback/<int:report_id>")
@login_required
def get_feedback(report_id):
    report = Report.query.get_or_404(report_id)
    
    # Ensure the report belongs to the current user
    if report.reporter_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    # Check if feedback already exists for this report
    feedback = Feedback.query.filter_by(report_id=report_id, user_id=current_user.id).first()
    
    if feedback:
        return jsonify({
            'exists': True,
            'id': feedback.id,
            'rating': feedback.rating,
            'message': feedback.message,
            'created_at': feedback.created_at.strftime('%B %d, %Y') if feedback.created_at else 'N/A'
        })
    
    return jsonify({
        'exists': False,
        'report_id': report_id,
        'report_title': report.title
    })

@resident_bp.route("/feedback/<int:report_id>", methods=['POST'])
@login_required
def submit_feedback(report_id):
    report = Report.query.get_or_404(report_id)
    
    # Ensure the report belongs to the current user
    if report.reporter_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    # Check if report is resolved
    if report.status != 'RESOLVED':
        return jsonify({'error': 'Can only provide feedback for resolved reports'}), 400
    
    data = request.get_json()
    rating = data.get('rating')
    message = data.get('message', '').strip()
    
    if not message:
        return jsonify({'error': 'Feedback message cannot be empty'}), 400
    
    if not rating or rating < 1 or rating > 5:
        return jsonify({'error': 'Rating must be between 1 and 5'}), 400
    
    # Check if feedback already exists
    existing_feedback = Feedback.query.filter_by(report_id=report_id, user_id=current_user.id).first()
    
    if existing_feedback:
        # Update existing feedback
        existing_feedback.rating = rating
        existing_feedback.message = message
        db.session.commit()
        return jsonify({'success': True, 'message': 'Feedback updated successfully!'})
    else:
        # Create new feedback
        feedback = Feedback(
            user_id=current_user.id,
            report_id=report_id,
            rating=rating,
            message=message
        )
        db.session.add(feedback)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Thank you for your feedback!'})
