from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.forms.infra_forms import InfrastructureForm
from app.models.infrastructure import Infrastructure

infra_bp = Blueprint("infra", __name__, url_prefix="/infrastructure")


@infra_bp.route("/", methods=["GET", "POST"])
@login_required
def manage():
    form = InfrastructureForm()

    try:
        infras = Infrastructure.query.order_by(Infrastructure.name.asc()).all()
    except SQLAlchemyError:
        db.session.rollback()
        infras = []
        flash("Unable to load infrastructure data right now.", "danger")

    if form.validate_on_submit():
        try:
            infra = Infrastructure(
                name=form.name.data,
                category=form.category.data,
                barangay="Poblacion III",  # Always Poblacion III
                status=form.status.data
            )

            db.session.add(infra)
            db.session.commit()
            flash("Infrastructure added!", "success")
            return redirect(url_for("infra.manage"))
        except ValueError as ve:
            db.session.rollback()
            flash(str(ve), "danger")
        except SQLAlchemyError as e:
            db.session.rollback()
            flash("Failed to save infrastructure. Please try again.", "danger")

    return render_template("admin/infrastructures.html", form=form, infras=infras)


@infra_bp.route("/<int:infra_id>", methods=["GET"])
@login_required
def get_infrastructure(infra_id):
    """Get infrastructure details for editing"""
    infra = Infrastructure.query.get_or_404(infra_id)
    return jsonify({
        'id': infra.id,
        'name': infra.name,
        'category': infra.category,
        'barangay': infra.barangay,
        'status': infra.status,
        'created_at': infra.created_at.strftime('%B %d, %Y') if infra.created_at else 'N/A'
    })


@infra_bp.route("/<int:infra_id>/update", methods=["POST"])
@login_required
def update_infrastructure(infra_id):
    """Update existing infrastructure"""
    infra = Infrastructure.query.get_or_404(infra_id)
    
    try:
        data = request.get_json() if request.is_json else request.form
        
        infra.name = data.get('name', infra.name)
        
        # Update category (case-insensitive)
        if 'category' in data:
            category = get_or_create_category(data.get('category'))
            infra.category_id = category.id
        
        # Barangay is always Poblacion III
        infra.barangay = "Poblacion III"
        
        infra.status = data.get('status', infra.status)
        
        db.session.commit()
        
        if request.is_json:
            return jsonify({'success': True, 'message': 'Infrastructure updated successfully!'})
        else:
            flash("Infrastructure updated successfully!", "success")
            return redirect(url_for("infra.manage"))
            
    except ValueError as ve:
        db.session.rollback()
        if request.is_json:
            return jsonify({'success': False, 'error': str(ve)}), 400
        else:
            flash(str(ve), "danger")
            return redirect(url_for("infra.manage"))
    except SQLAlchemyError as e:
        db.session.rollback()
        if request.is_json:
            return jsonify({'success': False, 'error': 'Failed to update infrastructure'}), 500
        else:
            flash("Failed to update infrastructure. Please try again.", "danger")
            return redirect(url_for("infra.manage"))


@infra_bp.route("/<int:infra_id>/delete", methods=["POST", "DELETE"])
@login_required
def delete_infrastructure(infra_id):
    """Delete infrastructure (only if no reports are linked)"""
    try:
        infra = Infrastructure.query.get_or_404(infra_id)
        
        # Check if any reports are linked to this infrastructure
        from app.models.report import Report
        linked_reports = Report.query.filter_by(infrastructure_id=infra_id).count()
        
        if linked_reports > 0:
            return jsonify({
                'success': False, 
                'error': f'Cannot delete: {linked_reports} report(s) are linked to this infrastructure'
            }), 400
        
        # Safe to delete
        db.session.delete(infra)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Infrastructure deleted successfully!'}), 200
            
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting infrastructure {infra_id}: {str(e)}")
        return jsonify({'success': False, 'error': f'Failed to delete infrastructure: {str(e)}'}), 500

