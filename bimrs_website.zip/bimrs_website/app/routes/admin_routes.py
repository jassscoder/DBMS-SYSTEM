from flask import Blueprint, render_template, jsonify
from flask_login import login_required
from app.models.report import Report
from app.models.infrastructure import Infrastructure
from app.models.user import User
from app.models.feedback import Feedback
from app.extensions import db

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route("/dashboard")
@login_required
def dashboard():
    """Admin dashboard with stats and overview"""
    try:
        total_reports = Report.query.count()
        pending = Report.query.filter_by(status="PENDING").count()
        in_progress = Report.query.filter_by(status="IN_PROGRESS").count()
        resolved = Report.query.filter_by(status="RESOLVED").count()
        infras = Infrastructure.query.count()
    except Exception:
        total_reports = 0
        pending = 0
        in_progress = 0
        resolved = 0
        infras = 0

    return render_template(
        "admin/dashboard.html",
        total_reports=total_reports,
        pending=pending,
        in_progress=in_progress,
        resolved=resolved,
        infras=infras,
    )


@admin_bp.route("/reports")
@login_required
def feed():
    """View all reports"""
    try:
        reports = Report.query.order_by(Report.created_at.desc()).all()
    except Exception:
        reports = []

    return render_template("admin/reports_feed.html", reports=reports)


@admin_bp.route("/reports/<int:report_id>")
@login_required
def report_detail(report_id):
    """Get report details as JSON for modal"""
    report = Report.query.get_or_404(report_id)
    try:
        return jsonify(
            {
                "id": report.id,
                "title": report.title,
                "category": report.category,
                "status": report.status,
                "description": report.description,
                "address": report.address,
                "contact_number": report.contact_number,
                "image_path": report.image_path,
                "reporter": report.reporter.username if report.reporter else "N/A",
                "reporter_email": report.reporter.email if report.reporter else "N/A",
                "infrastructure": report.infrastructure.name if report.infrastructure else "N/A",
                "created_at": report.created_at.strftime("%B %d, %Y at %I:%M %p")
                if report.created_at
                else "N/A",
                "resolved_at": report.resolved_at.strftime("%B %d, %Y at %I:%M %p")
                if report.resolved_at
                else "N/A",
            }
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@admin_bp.route("/users")
@login_required
def users():
    """View all resident users"""
    try:
        users = User.query.filter_by(role="resident").order_by(User.created_at.desc()).all()
    except Exception:
        users = []

    return render_template("admin/users.html", users=users)


@admin_bp.route("/users/<int:user_id>")
@login_required
def user_detail(user_id):
    """Get user details as JSON for modal"""
    user = User.query.get_or_404(user_id)
    report_count = Report.query.filter_by(reporter_id=user.id).count()

    return jsonify(
        {
            "id": user.id,
            "name": user.name or "N/A",
            "username": user.username,
            "email": user.email,
            "address": user.address or "N/A",
            "contact_number": user.contact_number or "N/A",
            "role": user.role,
            "is_suspended": user.is_suspended,
            "created_at": user.created_at.strftime("%B %d, %Y at %I:%M %p")
            if user.created_at
            else "N/A",
            "total_reports": report_count,
        }
    )


@admin_bp.route("/users/<int:user_id>/suspend", methods=["POST"])
@login_required
def suspend_user(user_id):
    """Suspend a user account"""
    user = User.query.get_or_404(user_id)
    try:
        user.is_suspended = True
        db.session.commit()
        return jsonify({"success": True, "message": f"User {user.username} has been suspended."})
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "error": str(e)}), 500


@admin_bp.route("/users/<int:user_id>/activate", methods=["POST"])
@login_required
def activate_user(user_id):
    """Reactivate a suspended user account"""
    user = User.query.get_or_404(user_id)
    try:
        user.is_suspended = False
        db.session.commit()
        return jsonify({"success": True, "message": f"User {user.username} has been reactivated."})
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "error": str(e)}), 500


@admin_bp.route("/users/<int:user_id>/delete", methods=["POST", "DELETE"])
@login_required
def delete_user(user_id):
    """Delete a resident user account. Prevent deletion if user has linked reports or is admin."""
    user = User.query.get_or_404(user_id)

    if user.role == "admin":
        return jsonify({"success": False, "error": "Cannot delete admin accounts."}), 400

    try:
        linked_reports = Report.query.filter_by(reporter_id=user.id).count()
        if linked_reports > 0:
            return jsonify(
                {
                    "success": False,
                    "error": f"Cannot delete: {linked_reports} report(s) are linked to this user.",
                }
            ), 400

        db.session.delete(user)
        db.session.commit()
        return jsonify({"success": True, "message": f"User {user.username} deleted successfully."})
    except Exception:
        db.session.rollback()
        return jsonify({"success": False, "error": "Failed to delete user."}), 500


@admin_bp.route("/feedbacks")
@login_required
def feedbacks():
    """View all feedbacks"""
    try:
        feedbacks = Feedback.query.order_by(Feedback.created_at.desc()).all()
    except Exception:
        feedbacks = []

    return render_template("admin/feedbacks_feed.html", feedbacks=feedbacks)


@admin_bp.route("/logs")
@login_required
def logs():
    """View activity logs using resolved reports for table display"""
    try:
        logs = Report.query.filter_by(status="RESOLVED").order_by(Report.resolved_at.desc()).all()
    except Exception:
        logs = []

    return render_template("admin/logs.html", logs=logs)


@admin_bp.route("/summary")
@login_required
def summary():
    """Admin summary view with infrastructure status breakdown"""
    try:
        good_count = Infrastructure.query.filter_by(status="Good").count()
        repair_count = Infrastructure.query.filter_by(status="Needs Repair").count()
        damaged_count = Infrastructure.query.filter_by(status="Damaged").count()
        resolved_total = Report.query.filter_by(status="RESOLVED").count()
    except Exception:
        good_count = 0
        repair_count = 0
        damaged_count = 0
        resolved_total = 0

    return render_template(
        "admin/summary.html",
        good_count=good_count,
        repair_count=repair_count,
        damaged_count=damaged_count,
        resolved_total=resolved_total,
    )
