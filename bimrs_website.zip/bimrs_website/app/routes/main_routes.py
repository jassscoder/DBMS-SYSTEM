from flask import Blueprint, redirect, url_for, render_template, current_app, request, jsonify
from flask_login import current_user
from app.models.report import Report
import os
from app.utils.email_helpers import send_email

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """Root route: redirect authenticated users to their dashboard,
    otherwise show the homepage."""
    if current_user.is_authenticated:
        if getattr(current_user, "role", None) == "admin":
            return redirect(url_for("admin.dashboard"))
        return redirect(url_for("resident.dashboard"))

    # Get hero image path from config
    try:
        hero_image_dir = current_app.config.get("HERO_IMAGE_DIRECTORY", "static/mock_images/hero.jpg")
        hero_video_url = current_app.config.get("HERO_VIDEO_URL", "")
        
        # Handle image path - if it starts with "static/", use url_for, otherwise use as-is
        if hero_image_dir.startswith("static/"):
            # Remove "static/" prefix and use url_for
            image_path = hero_image_dir.replace("static/", "")
            hero_image_url = url_for("static", filename=image_path)
        elif os.path.isabs(hero_image_dir):
            # Absolute path - use as-is (for external URLs or absolute paths)
            hero_image_url = hero_image_dir
        else:
            # Relative path - assume it's in static folder
            hero_image_url = url_for("static", filename=hero_image_dir)
    except Exception as e:
        # Fallback if there's any error
        hero_image_url = url_for("static", filename="mock_images/hero.jpg")
        hero_video_url = ""
    
    # Get last 3 resolved reports for recent projects
    try:
        recent_projects = Report.query.filter_by(status="RESOLVED").order_by(Report.resolved_at.desc()).limit(3).all()
    except Exception:
        recent_projects = []
    
    return render_template(
        "homepage.html",
        hero_image_url=hero_image_url,
        hero_video_url=hero_video_url,
        recent_projects=recent_projects,
        is_homepage=True
    )


@main_bp.route('/services')
def services():
    """Services page"""
    return render_template("main/services.html", is_homepage=False)

@main_bp.route('/portfolio')
def portfolio():
    """Portfolio page: show last 6 resolved projects"""
    try:
        recent_projects = Report.query.filter_by(status="RESOLVED").order_by(Report.resolved_at.desc()).limit(6).all()
    except Exception:
        recent_projects = []
    return render_template("main/portfolio.html", is_homepage=False, recent_projects=recent_projects)

@main_bp.route('/about')
def about():
    """About Us page"""
    return render_template("main/about.html", is_homepage=False)

@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    """Contact Us page and form submission"""
    if request.method == 'POST':
        try:
            data = request.get_json()
            name = data.get('name', '').strip()
            email = data.get('email', '').strip()
            subject = data.get('subject', '').strip()
            message = data.get('message', '').strip()
            
            # Basic validation
            if not all([name, email, subject, message]):
                return jsonify({'success': False, 'error': 'All fields are required'}), 400
            
            # Here you would typically:
            # 1. Save to database (create a ContactMessage model)
            # 2. Send email notification to admin
            # 3. Send confirmation email to user
            # Build email content and send to designated address
            subject_line = f"Contact Form: {subject}"
            body = f"""New contact form submission\n\nName: {name}\nEmail: {email}\nSubject: {subject}\n\nMessage:\n{message}\n"""
            html = f"""
                <html><body>
                <h2>New Contact Form Submission</h2>
                <p><strong>Name:</strong> {name}</p>
                <p><strong>Email:</strong> {email}</p>
                <p><strong>Subject:</strong> {subject}</p>
                <p><strong>Message:</strong></p>
                <div style='white-space:pre-wrap;border-left:3px solid #c41e3a;padding-left:10px;'>{message}</div>
                </body></html>
            """

            success = send_email(subject_line, ["noreplybimrs@gmail.com"], body, html)

            if not success:
                return jsonify({'success': False, 'error': 'Failed to send email'}), 500

            return jsonify({
                'success': True,
                'message': 'Your message has been sent successfully! We will get back to you soon.'
            })
            
        except Exception as e:
            current_app.logger.error(f"Error processing contact form: {str(e)}")
            return jsonify({'success': False, 'error': 'Failed to send message'}), 500
    
    return render_template("main/contact.html", is_homepage=False)

@main_bp.route('/debug-login')
def debug_login():
    return '<html><body><h1>DEBUG LOGIN OK</h1></body></html>'
