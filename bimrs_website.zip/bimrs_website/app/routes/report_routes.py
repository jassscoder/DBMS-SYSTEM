from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from sqlalchemy.exc import SQLAlchemyError
from app.extensions import db
from app.forms.report_forms import ReportForm, UpdateStatusForm
from app.models.report import Report
from app.models.infrastructure import Infrastructure
from app.utils.image_helpers import save_image
from app.utils.validation import is_address_in_barangay
from app.utils.email_helpers import send_resolution_email, send_report_status_email
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

report_bp = Blueprint("reports", __name__, url_prefix="/reports")

# CREATE REPORT
@report_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_report():
    form = ReportForm()
    
    # Get infrastructure data with categories for filtering (always needed)
    infrastructures = Infrastructure.query.order_by(Infrastructure.name).all()
    infra_data = [{"id": i.id, "name": i.name, "category": i.category.lower()} for i in infrastructures]

    if form.validate_on_submit():
        if not is_address_in_barangay(form.address.data):
            flash("Report rejected — address must be within Población Barangay III.", "danger")
            return render_template("resident/submit_report.html", form=form, infra_data=infra_data)

        # Handle image upload
        filename = None
        # Prefer WTForms file, but fall back to raw request in case binding fails
        uploaded_file = form.image.data
        if not uploaded_file:
            uploaded_file = request.files.get('image')

        if uploaded_file and getattr(uploaded_file, 'filename', ''):
            try:
                filename = save_image(uploaded_file)
            except ValueError as e:
                flash(f"Image upload failed: {str(e)}", "danger")
                return render_template("resident/submit_report.html", form=form, infra_data=infra_data)
            except Exception as e:
                flash(f"Image upload error: {str(e)}", "danger")
                return render_template("resident/submit_report.html", form=form, infra_data=infra_data)

        # Get infrastructure ID
        infra_id = form.infrastructure.data if form.infrastructure.data else None

        report = Report(
            reporter_id=current_user.id,
            title=form.title.data,
            category=form.category.data,  # Use category string from form
            description=form.description.data,
            address=form.address.data,
            contact_number=form.contact_number.data,
            image_path=filename,
            infrastructure_id=infra_id,
            status="PENDING"
        )

        try:
            db.session.add(report)
            db.session.commit()
            # Send initial PENDING notification to the reporter
            try:
                send_report_status_email(report, old_status=None)
            except Exception as e:
                # Log but don't block submission flow
                logger.error(f"Failed to send PENDING notification for Report #{report.id}: {str(e)}")
            flash("Report submitted successfully!", "success")
            return redirect(url_for("resident.dashboard"))
        except SQLAlchemyError as e:
            db.session.rollback()
            flash("Failed to submit report. Please try again.", "danger")
            return render_template("resident/submit_report.html", form=form, infra_data=infra_data)
    
    # Display form validation errors
    if form.errors:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", "danger")

    return render_template("resident/submit_report.html", form=form, infra_data=infra_data)

# UPDATE STATUS (admin)
@report_bp.route("/<int:report_id>/update_status", methods=["POST"])
@login_required
def update_status(report_id):
    # Eagerly load the reporter relationship to avoid lazy loading issues
    from sqlalchemy.orm import joinedload
    report = Report.query.options(joinedload(Report.reporter)).get_or_404(report_id)
    
    old_status = report.status
    new_status = request.form.get("status")
    valid_statuses = {"PENDING", "IN_PROGRESS", "RESOLVED", "DECLINED"}
    
    logger.info(f"Status update requested for Report #{report_id}: {old_status} -> {new_status}")

    if new_status not in valid_statuses:
        flash("Invalid status selected.", "danger")
        return redirect(url_for("admin.feed"))

    try:
        if new_status == "DECLINED":
            # Notify reporter before removing the record
            email_sent = False
            try:
                report.status = "DECLINED"
                email_sent = send_report_status_email(report, old_status)
            except Exception as e:
                logger.error(f"Failed to send DECLINED notification for Report #{report.id}: {str(e)}")

            # If declining, remove the report record entirely
            # Optionally remove uploaded image file if present
            try:
                from flask import current_app
                if report.image_path:
                    import os
                    upload_folder = current_app.config.get("UPLOAD_FOLDER")
                    if upload_folder:
                        file_path = os.path.join(upload_folder, report.image_path)
                        if os.path.isfile(file_path):
                            os.remove(file_path)
            except Exception:
                # Ignore file deletion errors; proceed with DB deletion
                pass

            db.session.delete(report)
            db.session.commit()
            if email_sent:
                flash("Report declined, removed, and email sent to reporter.", "success")
            else:
                flash("Report declined and removed, but email notification failed.", "warning")
            return redirect(url_for("admin.feed"))

        # Otherwise, update status and timestamps
        report.status = new_status
        if new_status == "RESOLVED":
            report.resolved_at = datetime.utcnow()
        else:
            report.resolved_at = None

        # Commit the changes
        db.session.commit()
        
        # Send email notification for status changes
        # Reporter relationship is already loaded, so no need to refresh
        logger.info(f"Attempting to send email for Report #{report.id} to {report.reporter.email if report.reporter else 'NO REPORTER'}")
        try:
            result = send_report_status_email(report, old_status)
            if result:
                logger.info(f"Status email sent successfully for Report #{report.id}: {old_status} -> {new_status}")
                flash(f"Status updated to {new_status}! Email notification sent to reporter.", "success")
            else:
                logger.warning(f"Email function returned False for Report #{report.id}")
                flash(f"Status updated to {new_status}, but email notification failed.", "warning")
        except Exception as e:
            flash(f"Status updated to {new_status}, but email notification failed.", "warning")
            logger.error(f"Failed to send status notification for Report #{report.id}: {str(e)}")
            import traceback
            traceback.print_exc()
            
    except SQLAlchemyError as e:
        db.session.rollback()
        logger.error(f"Failed to update report status: {str(e)}")
        flash("Failed to update status. Please try again.", "danger")

    return redirect(url_for("admin.feed"))


# EDIT REPORT (residents only, PENDING reports only)
@report_bp.route("/<int:report_id>/edit", methods=["GET", "POST"])
@login_required
def edit_report(report_id):
    report = Report.query.get_or_404(report_id)
    
    # Ensure the report belongs to the current user
    if report.reporter_id != current_user.id:
        flash("You can only edit your own reports.", "danger")
        return redirect(url_for("resident.dashboard"))
    
    # Only allow editing of PENDING reports
    if report.status != "PENDING":
        flash("You can only edit reports that are in PENDING status.", "danger")
        return redirect(url_for("resident.dashboard"))
    
    form = ReportForm()
    
    # Get infrastructure data with categories for filtering (always needed)
    infrastructures = Infrastructure.query.order_by(Infrastructure.name).all()
    infra_data = [{"id": i.id, "name": i.name, "category": i.category.lower()} for i in infrastructures]
    
    # Form automatically populates choices from database in __init__
    
    if form.validate_on_submit():
        if not is_address_in_barangay(form.address.data):
            flash("Report rejected — address must be within Población Barangay III.", "danger")
            return render_template("resident/submit_report.html", form=form, edit_mode=True, report=report, infra_data=infra_data)
        
        # Handle image removal (when editing)
        remove_image = request.form.get('remove_image', '0') == '1'
        if remove_image and report.image_path:
            try:
                from flask import current_app
                import os
                upload_folder = current_app.config.get("UPLOAD_FOLDER")
                if upload_folder:
                    old_file_path = os.path.join(upload_folder, report.image_path)
                    if os.path.isfile(old_file_path):
                        os.remove(old_file_path)
                report.image_path = None
            except Exception as e:
                flash(f"Failed to remove image: {str(e)}", "warning")
        
        # Handle image upload (optional when editing)
        uploaded_file = form.image.data
        if not uploaded_file:
            uploaded_file = request.files.get('image')
        
        if uploaded_file and getattr(uploaded_file, 'filename', '') and uploaded_file.filename:
            try:
                # Delete old image if exists
                if report.image_path:
                    from flask import current_app
                    import os
                    upload_folder = current_app.config.get("UPLOAD_FOLDER")
                    if upload_folder:
                        old_file_path = os.path.join(upload_folder, report.image_path)
                        if os.path.isfile(old_file_path):
                            os.remove(old_file_path)
                
                # Save new image
                filename = save_image(uploaded_file)
                report.image_path = filename
            except ValueError as e:
                flash(f"Image upload failed: {str(e)}", "danger")
                return render_template("resident/submit_report.html", form=form, edit_mode=True, report=report, infra_data=infra_data)
            except Exception as e:
                flash(f"Image upload error: {str(e)}", "danger")
                return render_template("resident/submit_report.html", form=form, edit_mode=True, report=report, infra_data=infra_data)
        
        # Update report fields
        report.title = form.title.data
        report.category = form.category.data
        report.description = form.description.data
        report.address = form.address.data
        report.contact_number = form.contact_number.data
        
        # Get infrastructure ID (None if user selected "None")
        infra_id = form.infrastructure.data if form.infrastructure.data != 0 else None
        report.infrastructure_id = infra_id
        
        try:
            db.session.commit()
            
            # Send email notification for report update
            try:
                send_report_status_email(report, old_status=report.status)
                flash("Report updated successfully! Confirmation email sent.", "success")
            except Exception as e:
                flash("Report updated successfully!", "success")
                logger.error(f"Failed to send update notification for Report #{report.id}: {str(e)}")
            
            return redirect(url_for("resident.dashboard"))
        except SQLAlchemyError as e:
            db.session.rollback()
            flash("Failed to update report. Please try again.", "danger")
            return render_template("resident/submit_report.html", form=form, edit_mode=True, report=report, infra_data=infra_data)
    
    # Pre-populate form with existing data on GET request
    if request.method == "GET":
        form.title.data = report.title
        form.category.data = report.category
        form.description.data = report.description
        form.address.data = report.address
        form.contact_number.data = report.contact_number
        form.infrastructure.data = report.infrastructure_id if report.infrastructure_id else 0
    
    # Display form validation errors
    if form.errors:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", "danger")
    
    return render_template("resident/submit_report.html", form=form, edit_mode=True, report=report, infra_data=infra_data)
