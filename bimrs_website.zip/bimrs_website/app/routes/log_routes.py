from flask import Blueprint, render_template
from flask_login import login_required
from app.models.report import Report

log_bp = Blueprint("logs", __name__, url_prefix="/logs")

@log_bp.route("/")
@login_required
def view_logs():
    # Get all resolved reports ordered by resolution date (newest first)
    resolved_reports = Report.query.filter_by(status="RESOLVED").order_by(Report.resolved_at.desc()).all()
    return render_template("admin/logs.html", logs=resolved_reports)
