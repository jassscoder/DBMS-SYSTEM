# app/utils/validation.py

import re

def is_address_in_barangay(address: str, barangay_name: str = "Poblacion") -> bool:
    """
    Checks if the provided address contains the barangay name.
    Case-insensitive.
    """
    if not address:
        return False

    return barangay_name.lower() in address.lower()


def is_valid_contact_number(contact: str) -> bool:
    """
    Validates PH mobile numbers (e.g., 09xxxxxxxxx or +639xxxxxxxxx).
    """
    pattern = r"^(09\d{9}|\+639\d{9})$"
    return bool(re.match(pattern, contact))


def is_valid_username(username: str) -> bool:
    """
    Ensures username contains only letters, numbers, underscores.
    """
    pattern = r"^[a-zA-Z0-9_]+$"
    return bool(re.match(pattern, username))
