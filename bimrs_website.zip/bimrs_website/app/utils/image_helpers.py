# app/utils/image_helpers.py

import os
import uuid
from flask import current_app
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "gif"}


def allowed_file(filename: str) -> bool:
    """Return True if filename has an allowed extension."""
    return bool(filename and "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS)


def save_image(file):
    """
    Save an uploaded image into the configured UPLOAD_FOLDER with a unique safe name.
    Returns the filename (not the full path) or raises ValueError on invalid input.
    """
    if file is None:
        raise ValueError("No file provided")
    
    # Check if filename exists and is not empty
    if not hasattr(file, 'filename') or not file.filename or file.filename == "":
        raise ValueError("No file selected")

    # Sanitize original filename and check extension
    original = secure_filename(file.filename)
    if not original:
        raise ValueError("Invalid filename")
    
    if not allowed_file(original):
        raise ValueError(f"File type not allowed. Only {', '.join(ALLOWED_EXTENSIONS)} are supported")

    # Keep extension and create a unique filename to avoid collisions
    _, ext = os.path.splitext(original)
    unique_name = f"{uuid.uuid4().hex}{ext.lower()}"

    # Determine upload folder from app config (fallback to app/static/uploads)
    upload_folder = current_app.config.get("UPLOAD_FOLDER")
    if not upload_folder:
        upload_folder = os.path.join(current_app.root_path, "static", "uploads")

    # Ensure the folder exists (safe to call repeatedly)
    os.makedirs(upload_folder, exist_ok=True)

    upload_path = os.path.join(upload_folder, unique_name)

    try:
        # Save the file to disk
        file.save(upload_path)
    except Exception as e:
        raise ValueError(f"Failed to save file: {str(e)}")

    # Return only the filename so callers can store it in the DB
    return unique_name
