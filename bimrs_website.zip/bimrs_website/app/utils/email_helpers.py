# app/utils/email_helpers.py

from flask_mail import Message
from flask import current_app
from datetime import datetime
import logging
import time

# Configure logger
logger = logging.getLogger(__name__)

def send_email(subject, recipients, body, html=None, retry_count=2):
    """
    Sends an email using Flask-Mail with retry mechanism.
    
    Args:
        subject: Email subject line
        recipients: List of recipient email addresses
        body: Plain text email body
        html: HTML email body (optional)
        retry_count: Number of retry attempts if sending fails (default: 2)
    
    Returns:
        bool: True if email sent successfully, False otherwise
    """
    from app.extensions import mail
    
    # Get sender from config or use a default
    sender = current_app.config.get("MAIL_DEFAULT_SENDER")
    if not sender:
        sender = current_app.config.get("MAIL_USERNAME")
    
    if not sender:
        logger.error("[EMAIL ERROR] No sender configured - check MAIL_DEFAULT_SENDER or MAIL_USERNAME")
        return False

    msg = Message(
        subject=subject,
        recipients=recipients,
        body=body,
        html=html,
        sender=sender
    )

    for attempt in range(retry_count + 1):
        try:
            mail.send(msg)
            logger.info(f"[EMAIL SUCCESS] Sent to {recipients} - Subject: {subject}")
            return True
        except Exception as e:
            if attempt < retry_count:
                logger.warning(f"[EMAIL RETRY] Attempt {attempt + 1} failed for {recipients}: {str(e)}. Retrying in 2 seconds...")
                time.sleep(2)  # Wait before retry
            else:
                logger.error(f"[EMAIL ERROR] Failed to send to {recipients} after {retry_count + 1} attempts: {str(e)}")
                return False
    
    return False


def send_report_status_email(report, old_status=None):
    """
    Send email notification when report status changes.
    Handles PENDING, IN_PROGRESS, RESOLVED, and DECLINED statuses.
    
    Args:
        report: Report object with status and reporter information
        old_status: Previous status of the report (optional)
    
    Returns:
        bool: True if email sent successfully, False otherwise
    """
    if not report or not getattr(report, 'reporter', None):
        logger.warning("[EMAIL] No report or reporter found - cannot send notification")
        return False

    reporter = report.reporter
    if not reporter.email:
        logger.warning(f"[EMAIL] Reporter {reporter.username} has no email address - cannot send notification")
        return False

    status = report.status or "PENDING"
    username = reporter.username or "Resident"
    
    logger.info(f"[EMAIL] Preparing status notification for Report #{report.id}: {old_status or 'NEW'} -> {status}")
    
    # Build email content based on status
    if status == "RESOLVED":
        subject = f"Report Resolved: {report.title}"
        body = f"""Dear {username},

We are pleased to inform you that your infrastructure report has been successfully resolved.

Report Summary:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Report ID: #{report.id}
Title: {report.title}
Category: {report.category}
Location: {report.address or 'N/A'}
Status: RESOLVED
Resolution Date: {report.resolved_at.strftime('%B %d, %Y at %I:%M %p') if report.resolved_at else datetime.utcnow().strftime('%B %d, %Y at %I:%M %p')}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your report has been processed and the issue has been addressed. Thank you for bringing this matter to our attention. Your civic engagement contributes significantly to the development and maintenance of our community infrastructure.

If you have any follow-up concerns or require further assistance, please do not hesitate to contact the Barangay Office.

Best regards,
Barangay Infrastructure Management & Reporting System
Población Barangay III
"""
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background-color: #f5f5f5; }}
        .container {{ max-width: 600px; margin: 20px auto; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden; }}
        .header {{ background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; padding: 40px 20px; text-align: center; }}
        .header h1 {{ font-size: 28px; margin-bottom: 10px; }}
        .header p {{ font-size: 14px; opacity: 0.9; }}
        .content {{ padding: 30px 20px; }}
        .content h2 {{ color: #333; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #28a745; padding-bottom: 10px; }}
        .detail-box {{ background: #f8f9fa; border-left: 4px solid #28a745; padding: 15px; margin-bottom: 20px; border-radius: 4px; }}
        .detail-row {{ display: flex; margin-bottom: 8px; }}
        .detail-label {{ font-weight: 600; color: #555; min-width: 120px; }}
        .detail-value {{ color: #333; flex: 1; }}
        .message {{ color: #555; margin-bottom: 20px; line-height: 1.8; }}
        .footer {{ background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eee; color: #666; font-size: 12px; }}
        .footer p {{ margin-bottom: 5px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>✓ Report Resolved</h1>
            <p>Your infrastructure report has been successfully processed</p>
        </div>
        <div class="content">
            <p class="message">Dear <strong>{username}</strong>,</p>
            <p class="message">We are pleased to inform you that your infrastructure report has been successfully resolved.</p>
            
            <h2>Report Summary</h2>
            <div class="detail-box">
                <div class="detail-row">
                    <span class="detail-label">Report ID:</span>
                    <span class="detail-value">#{report.id}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Title:</span>
                    <span class="detail-value">{report.title}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Category:</span>
                    <span class="detail-value">{report.category}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Status:</span>
                    <span class="detail-value" style="color: #28a745; font-weight: 600;">RESOLVED</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Resolved Date:</span>
                    <span class="detail-value">{report.resolved_at.strftime('%B %d, %Y at %I:%M %p') if report.resolved_at else datetime.utcnow().strftime('%B %d, %Y at %I:%M %p')}</span>
                </div>
            </div>
            
            <p class="message">Your report has been processed and the issue has been addressed. Thank you for bringing this matter to our attention. Your civic engagement contributes significantly to the development and maintenance of our community infrastructure.</p>
            <p class="message">If you have any follow-up concerns or require further assistance, please do not hesitate to contact the Barangay Office.</p>
        </div>
        <div class="footer">
            <p><strong>Barangay Infrastructure Management & Reporting System</strong></p>
            <p>Población Barangay III</p>
        </div>
    </div>
</body>
</html>
"""
    
    elif status == "IN_PROGRESS":
        subject = f"Update: Your Report Is Being Processed - {report.title}"
        body = f"""Dear {username},

Thank you for your patience. We are writing to inform you that your infrastructure report is currently being processed.

Report Summary:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Report ID: #{report.id}
Title: {report.title}
Category: {report.category}
Location: {report.address or 'N/A'}
Status: IN PROGRESS
Updated on: {datetime.utcnow().strftime('%B %d, %Y at %I:%M %p')}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Our team is currently addressing the issue you reported. We will keep you informed of any progress and notify you upon resolution. You can expect further updates soon.

For urgent inquiries, please contact the Barangay Office directly.

Best regards,
Barangay Infrastructure Management & Reporting System
Población Barangay III
"""
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background-color: #f5f5f5; }}
        .container {{ max-width: 600px; margin: 20px auto; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden; }}
        .header {{ background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%); color: #333; padding: 40px 20px; text-align: center; }}
        .header h1 {{ font-size: 28px; margin-bottom: 10px; }}
        .header p {{ font-size: 14px; opacity: 0.9; }}
        .content {{ padding: 30px 20px; }}
        .content h2 {{ color: #333; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #ffc107; padding-bottom: 10px; }}
        .detail-box {{ background: #f8f9fa; border-left: 4px solid #ffc107; padding: 15px; margin-bottom: 20px; border-radius: 4px; }}
        .detail-row {{ display: flex; margin-bottom: 8px; }}
        .detail-label {{ font-weight: 600; color: #555; min-width: 120px; }}
        .detail-value {{ color: #333; flex: 1; }}
        .message {{ color: #555; margin-bottom: 20px; line-height: 1.8; }}
        .footer {{ background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eee; color: #666; font-size: 12px; }}
        .footer p {{ margin-bottom: 5px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>⏳ In Progress</h1>
            <p>Your report is being actively processed</p>
        </div>
        <div class="content">
            <p class="message">Dear <strong>{username}</strong>,</p>
            <p class="message">Thank you for your patience. We are writing to inform you that your infrastructure report is currently being processed.</p>
            
            <h2>Report Summary</h2>
            <div class="detail-box">
                <div class="detail-row">
                    <span class="detail-label">Report ID:</span>
                    <span class="detail-value">#{report.id}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Title:</span>
                    <span class="detail-value">{report.title}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Category:</span>
                    <span class="detail-value">{report.category}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Location:</span>
                    <span class="detail-value">{report.address or 'N/A'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Status:</span>
                    <span class="detail-value" style="color: #ff9800; font-weight: 600;">IN PROGRESS</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Updated on:</span>
                    <span class="detail-value">{datetime.utcnow().strftime('%B %d, %Y at %I:%M %p')}</span>
                </div>
            </div>
            
            <p class="message">Our team is currently addressing the issue you reported. We will keep you informed of any progress and notify you upon resolution. You can expect further updates soon.</p>
            <p class="message">For urgent inquiries, please contact the Barangay Office directly.</p>
        </div>
        <div class="footer">
            <p><strong>Barangay Infrastructure Management & Reporting System</strong></p>
            <p>Población Barangay III</p>
        </div>
    </div>
</body>
</html>
"""
    
    elif status == "PENDING":
        subject = f"Report Received: {report.title}"
        body = f"""Dear {username},

Your infrastructure report has been successfully submitted and received.

Report Summary:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Report ID: #{report.id}
Title: {report.title}
Category: {report.category}
Location: {report.address or 'N/A'}
Status: PENDING REVIEW
Submitted on: {datetime.utcnow().strftime('%B %d, %Y at %I:%M %p')}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your report is now in the queue and will be reviewed by our administrative team shortly. You will be notified via email as soon as there are any updates to your report status.

Thank you for your civic participation and for helping us maintain the quality of our community infrastructure.

Best regards,
Barangay Infrastructure Management & Reporting System
Población Barangay III
"""
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background-color: #f5f5f5; }}
        .container {{ max-width: 600px; margin: 20px auto; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden; }}
        .header {{ background: linear-gradient(135deg, #6c757d 0%, #495057 100%); color: white; padding: 40px 20px; text-align: center; }}
        .header h1 {{ font-size: 28px; margin-bottom: 10px; }}
        .header p {{ font-size: 14px; opacity: 0.9; }}
        .content {{ padding: 30px 20px; }}
        .content h2 {{ color: #333; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #6c757d; padding-bottom: 10px; }}
        .detail-box {{ background: #f8f9fa; border-left: 4px solid #6c757d; padding: 15px; margin-bottom: 20px; border-radius: 4px; }}
        .detail-row {{ display: flex; margin-bottom: 8px; }}
        .detail-label {{ font-weight: 600; color: #555; min-width: 120px; }}
        .detail-value {{ color: #333; flex: 1; }}
        .message {{ color: #555; margin-bottom: 20px; line-height: 1.8; }}
        .footer {{ background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eee; color: #666; font-size: 12px; }}
        .footer p {{ margin-bottom: 5px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📋 Report Received</h1>
            <p>Your report has been successfully submitted</p>
        </div>
        <div class="content">
            <p class="message">Dear <strong>{username}</strong>,</p>
            <p class="message">Your infrastructure report has been successfully submitted and received.</p>
            
            <h2>Report Summary</h2>
            <div class="detail-box">
                <div class="detail-row">
                    <span class="detail-label">Report ID:</span>
                    <span class="detail-value">#{report.id}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Title:</span>
                    <span class="detail-value">{report.title}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Category:</span>
                    <span class="detail-value">{report.category}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Location:</span>
                    <span class="detail-value">{report.address or 'N/A'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Status:</span>
                    <span class="detail-value" style="color: #6c757d; font-weight: 600;">PENDING REVIEW</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Submitted on:</span>
                    <span class="detail-value">{datetime.utcnow().strftime('%B %d, %Y at %I:%M %p')}</span>
                </div>
            </div>
            
            <p class="message">Your report is now in the queue and will be reviewed by our administrative team shortly. You will be notified via email as soon as there are any updates to your report status.</p>
            <p class="message">Thank you for your civic participation and for helping us maintain the quality of our community infrastructure.</p>
        </div>
        <div class="footer">
            <p><strong>Barangay Infrastructure Management & Reporting System</strong></p>
            <p>Población Barangay III</p>
        </div>
    </div>
</body>
</html>
"""
    
    elif status == "DECLINED":
        subject = f"Report Status Update: {report.title}"
        body = f"""Dear {username},

We appreciate you taking the time to submit your infrastructure report. After careful review, your report has been marked as declined.

Report Summary:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Report ID: #{report.id}
Title: {report.title}
Category: {report.category}
Location: {report.address or 'N/A'}
Status: DECLINED
Updated on: {datetime.utcnow().strftime('%B %d, %Y at %I:%M %p')}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This may be due to various reasons such as the issue being outside barangay jurisdiction, duplicate reports, or insufficient information. If you believe this decision is incorrect or if you have additional information to support your report, please contact the Barangay Office to discuss further.

We encourage you to continue reporting legitimate infrastructure concerns in the future.

Best regards,
Barangay Infrastructure Management & Reporting System
Población Barangay III
"""
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background-color: #f5f5f5; }}
        .container {{ max-width: 600px; margin: 20px auto; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden; }}
        .header {{ background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; padding: 40px 20px; text-align: center; }}
        .header h1 {{ font-size: 28px; margin-bottom: 10px; }}
        .header p {{ font-size: 14px; opacity: 0.9; }}
        .content {{ padding: 30px 20px; }}
        .content h2 {{ color: #333; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #dc3545; padding-bottom: 10px; }}
        .detail-box {{ background: #f8f9fa; border-left: 4px solid #dc3545; padding: 15px; margin-bottom: 20px; border-radius: 4px; }}
        .detail-row {{ display: flex; margin-bottom: 8px; }}
        .detail-label {{ font-weight: 600; color: #555; min-width: 120px; }}
        .detail-value {{ color: #333; flex: 1; }}
        .message {{ color: #555; margin-bottom: 20px; line-height: 1.8; }}
        .footer {{ background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eee; color: #666; font-size: 12px; }}
        .footer p {{ margin-bottom: 5px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Report Status Update</h1>
            <p>Your report has been reviewed</p>
        </div>
        <div class="content">
            <p class="message">Dear <strong>{username}</strong>,</p>
            <p class="message">We appreciate you taking the time to submit your infrastructure report. After careful review, your report has been marked as declined.</p>
            
            <h2>Report Summary</h2>
            <div class="detail-box">
                <div class="detail-row">
                    <span class="detail-label">Report ID:</span>
                    <span class="detail-value">#{report.id}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Title:</span>
                    <span class="detail-value">{report.title}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Category:</span>
                    <span class="detail-value">{report.category}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Location:</span>
                    <span class="detail-value">{report.address or 'N/A'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Status:</span>
                    <span class="detail-value" style="color: #dc3545; font-weight: 600;">DECLINED</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Updated on:</span>
                    <span class="detail-value">{datetime.utcnow().strftime('%B %d, %Y at %I:%M %p')}</span>
                </div>
            </div>
            
            <p class="message">This may be due to various reasons such as the issue being outside barangay jurisdiction, duplicate reports, or insufficient information. If you believe this decision is incorrect or if you have additional information to support your report, please contact the Barangay Office to discuss further.</p>
            <p class="message">We encourage you to continue reporting legitimate infrastructure concerns in the future.</p>
        </div>
        <div class="footer">
            <p><strong>Barangay Infrastructure Management & Reporting System</strong></p>
            <p>Población Barangay III</p>
        </div>
    </div>
</body>
</html>
"""
    
    else:
        # Default for any other status
        subject = f"Report Status Update: {report.title}"
        body = f"""Hello {username},\n\nYour report status has been updated.\n\nReport: {report.title}\nNew Status: {status}\n\nBest regards,\nBarangay Infrastructure Management & Reporting System"""
        html = None
    
    recipients = [reporter.email]
    return send_email(subject, recipients, body, html)


# Backward compatibility - keep old function name
def send_resolution_email(report):
    """
    Legacy function - redirects to send_report_status_email.
    """
    return send_report_status_email(report)
