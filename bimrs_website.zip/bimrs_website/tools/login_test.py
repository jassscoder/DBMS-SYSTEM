import requests
from bs4 import BeautifulSoup
s = requests.Session()
url = 'http://127.0.0.1:5000/auth/login'
r = s.get(url)
soup = BeautifulSoup(r.text, 'html.parser')
# find csrf token
csrf = None
csrf_input = soup.find('input', {'id':'csrf_token'}) or soup.find('input', {'name':'csrf_token'})
if csrf_input:
    csrf = csrf_input.get('value')
print('csrf=', csrf)

data = {'username':'admin','password':'admin123'}
if csrf:
    data['csrf_token']=csrf
r2 = s.post(url, data=data)
open('tools/login_post_result.html','w',encoding='utf-8').write(r2.text)
print('POST', r2.status_code)

# Try to access admin dashboard (if logged in)
rd = s.get('http://127.0.0.1:5000/admin/dashboard')
open('tools/admin_dashboard.html','w',encoding='utf-8').write(rd.text)
print('DASH', rd.status_code, 'len', len(rd.text))
