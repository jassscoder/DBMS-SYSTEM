"""
Test report status update with email
"""
import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from app.extensions import db
from app.models.report import Report
from app.models.user import User
from app.utils.email_helpers import send_report_status_email

def test_status_update():
    app = create_app()
    
    with app.app_context():
        print("=" * 60)
        print("TESTING STATUS UPDATE EMAIL")
        print("=" * 60)
        
        # Find a test report
        report = Report.query.first()
        
        if not report:
            print("✗ No reports found in database")
            return
        
        print(f"\nReport ID: {report.id}")
        print(f"Title: {report.title}")
        print(f"Current Status: {report.status}")
        print(f"Reporter ID: {report.reporter_id}")
        
        # Check if reporter exists and has email
        if report.reporter:
            print(f"Reporter: {report.reporter.username}")
            print(f"Reporter Email: {report.reporter.email}")
        else:
            print("✗ Reporter not found!")
            return
        
        if not report.reporter.email:
            print("✗ Reporter has no email address!")
            return
        
        print("\n" + "=" * 60)
        print("Attempting to send status email...")
        print("=" * 60)
        
        try:
            old_status = report.status
            result = send_report_status_email(report, old_status)
            
            if result:
                print(f"✓ EMAIL SENT SUCCESSFULLY to {report.reporter.email}")
            else:
                print("✗ Email function returned False")
                
        except Exception as e:
            print(f"✗ EXCEPTION: {type(e).__name__}")
            print(f"   Error: {str(e)}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    test_status_update()
