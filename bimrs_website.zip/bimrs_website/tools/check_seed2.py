import os, sys
this_dir = os.path.dirname(os.path.dirname(__file__))
if this_dir not in sys.path:
    sys.path.insert(0, this_dir)

from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.infrastructure import Infrastructure

app = create_app()
app.app_context().push()

out_path = os.path.join(os.path.dirname(__file__), 'check_seed2_result.txt')

u_count = User.query.count()
if_count = Infrastructure.query.count()

with open(out_path, 'w', encoding='utf-8') as f:
    f.write(f"users_count={u_count}\n")
    f.write(f"infrastructure_count={if_count}\n")

print('WROTE', out_path)
