"""
Database Health Check Script
Comprehensive validation of database integrity, schema alignment, and data consistency.
Run this script regularly to ensure database health.
"""

import pymysql
import os
import sys


def get_db_connection():
    """Create database connection using environment variables."""
    host = os.environ.get('DB_HOST', '127.0.0.1')
    user = os.environ.get('DB_USER', 'root')
    passwd = os.environ.get('DB_PASS', '')
    db_name = os.environ.get('DB_NAME', 'bimrs')
    
    return pymysql.connect(host=host, user=user, password=passwd, db=db_name)


def check_schema_alignment(cursor):
    """Verify database schema matches model definitions."""
    print("\n1. SCHEMA ALIGNMENT CHECK")
    print("-" * 70)
    
    issues = []
    
    # Check reports table
    cursor.execute("DESCRIBE reports")
    columns = cursor.fetchall()
    db_columns = [col[0] for col in columns]
    
    expected_report_columns = [
        'id', 'title', 'description', 'category', 'address', 'contact_number',
        'image_path', 'status', 'created_at', 'reporter_id', 
        'infrastructure_id', 'resolved_at'
    ]
    
    missing_cols = [col for col in expected_report_columns if col not in db_columns]
    if missing_cols:
        issues.append(f"Missing columns in reports table: {missing_cols}")
        print(f"  [ERROR] Missing columns: {missing_cols}")
    else:
        print("  [OK] Reports table schema matches model")
    
    return issues


def check_foreign_key_integrity(cursor):
    """Check all foreign key relationships are valid."""
    print("\n2. FOREIGN KEY INTEGRITY")
    print("-" * 70)
    
    issues = []
    
    # Check reports.reporter_id
    cursor.execute("""
        SELECT COUNT(*) FROM reports 
        WHERE reporter_id NOT IN (SELECT id FROM users)
    """)
    orphaned_reporters = cursor.fetchone()[0]
    if orphaned_reporters > 0:
        issues.append(f"{orphaned_reporters} reports have invalid reporter_id")
        print(f"  [ERROR] {orphaned_reporters} orphaned reporter_id references")
    else:
        print("  [OK] reports.reporter_id integrity")
    
    # Check reports.infrastructure_id
    cursor.execute("""
        SELECT COUNT(*) FROM reports 
        WHERE infrastructure_id IS NOT NULL 
        AND infrastructure_id NOT IN (SELECT id FROM infrastructure)
    """)
    orphaned_infra = cursor.fetchone()[0]
    if orphaned_infra > 0:
        issues.append(f"{orphaned_infra} reports have invalid infrastructure_id")
        print(f"  [ERROR] {orphaned_infra} orphaned infrastructure_id references")
    else:
        print("  [OK] reports.infrastructure_id integrity")
    
    # Check feedback.user_id
    cursor.execute("""
        SELECT COUNT(*) FROM feedback 
        WHERE user_id NOT IN (SELECT id FROM users)
    """)
    orphaned_feedback = cursor.fetchone()[0]
    if orphaned_feedback > 0:
        issues.append(f"{orphaned_feedback} feedback entries have invalid user_id")
        print(f"  [ERROR] {orphaned_feedback} orphaned user_id references")
    else:
        print("  [OK] feedback.user_id integrity")
    
    return issues


def check_data_validation(cursor):
    """Validate required fields and check for duplicates."""
    print("\n3. DATA VALIDATION")
    print("-" * 70)
    
    issues = []
    
    # Check for NULL required fields
    cursor.execute("SELECT COUNT(*) FROM users WHERE username IS NULL OR email IS NULL")
    null_users = cursor.fetchone()[0]
    if null_users > 0:
        issues.append(f"{null_users} users have NULL username or email")
        print(f"  [ERROR] {null_users} users with NULL username/email")
    else:
        print("  [OK] All users have username and email")
    
    # Check for duplicate usernames
    cursor.execute("""
        SELECT username, COUNT(*) as cnt 
        FROM users 
        GROUP BY username 
        HAVING cnt > 1
    """)
    dup_usernames = cursor.fetchall()
    if dup_usernames:
        issues.append(f"Duplicate usernames: {[u[0] for u in dup_usernames]}")
        print(f"  [ERROR] Duplicate usernames found")
    else:
        print("  [OK] No duplicate usernames")
    
    # Check for duplicate emails
    cursor.execute("""
        SELECT email, COUNT(*) as cnt 
        FROM users 
        GROUP BY email 
        HAVING cnt > 1
    """)
    dup_emails = cursor.fetchall()
    if dup_emails:
        issues.append(f"Duplicate emails: {[e[0] for e in dup_emails]}")
        print(f"  [ERROR] Duplicate emails found")
    else:
        print("  [OK] No duplicate emails")
    
    return issues


def check_indexes(cursor):
    """Verify necessary indexes exist."""
    print("\n4. INDEX CHECK")
    print("-" * 70)
    
    cursor.execute("SHOW INDEX FROM users WHERE Key_name != 'PRIMARY'")
    user_indexes = cursor.fetchall()
    print(f"  [OK] users table has {len(user_indexes)} indexes")
    
    cursor.execute("SHOW INDEX FROM reports WHERE Key_name != 'PRIMARY'")
    report_indexes = cursor.fetchall()
    print(f"  [OK] reports table has {len(report_indexes)} indexes")
    
    return []


def check_migration_status(cursor):
    """Check current migration version."""
    print("\n5. MIGRATION STATUS")
    print("-" * 70)
    
    cursor.execute("SELECT version_num FROM alembic_version")
    current_version = cursor.fetchone()
    print(f"  [OK] Current migration: {current_version[0]}")
    
    return []


def show_data_summary(cursor):
    """Display summary of data in database."""
    print("\n6. DATA SUMMARY")
    print("-" * 70)
    
    cursor.execute("SELECT COUNT(*) FROM users")
    print(f"  Users: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM reports")
    print(f"  Reports: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM infrastructure")
    print(f"  Infrastructure: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM feedback")
    print(f"  Feedback: {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM logs")
    print(f"  Logs: {cursor.fetchone()[0]}")


def main():
    """Run complete database health check."""
    print("=" * 70)
    print("           DATABASE HEALTH CHECK")
    print("=" * 70)
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        all_issues = []
        
        # Run all checks
        all_issues.extend(check_schema_alignment(cursor))
        all_issues.extend(check_foreign_key_integrity(cursor))
        all_issues.extend(check_data_validation(cursor))
        all_issues.extend(check_indexes(cursor))
        all_issues.extend(check_migration_status(cursor))
        show_data_summary(cursor)
        
        # Final verdict
        print("\n" + "=" * 70)
        if not all_issues:
            print("                  DATABASE STATUS: HEALTHY")
            print("         All checks passed! No errors detected.")
            print("=" * 70)
            cursor.close()
            conn.close()
            return 0
        else:
            print("                  DATABASE STATUS: ISSUES FOUND")
            print("\nCritical Issues:")
            for i, issue in enumerate(all_issues, 1):
                print(f"  {i}. {issue}")
            print("=" * 70)
            cursor.close()
            conn.close()
            return 1
            
    except pymysql.err.OperationalError as e:
        print(f"\n[FATAL ERROR] Cannot connect to database: {e}")
        print("\nPossible causes:")
        print("  1. MySQL server is not running")
        print("  2. Database credentials are incorrect")
        print("  3. Database 'bimrs' does not exist")
        return 2
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 3


if __name__ == "__main__":
    sys.exit(main())
