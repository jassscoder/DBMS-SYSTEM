import os
import pymysql
import traceback

host = os.environ.get('DB_HOST', '127.0.0.1')
user = os.environ.get('DB_USER', 'root')
passwd = os.environ.get('DB_PASS', '')
db = os.environ.get('DB_NAME', 'bimrs')

out_path = os.path.join(os.path.dirname(__file__), 'create_db_result.txt')

try:
    conn = pymysql.connect(host=host, user=user, password=passwd, connect_timeout=5)
    cur = conn.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS `{db}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
    conn.commit()
    cur.close()
    conn.close()
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(f"OK\nCreated or confirmed database {db} on {host}\n")
except Exception:
    err = traceback.format_exc()
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write("ERROR\n")
        f.write(err)
    raise
