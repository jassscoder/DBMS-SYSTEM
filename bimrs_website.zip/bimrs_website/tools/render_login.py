import os, sys
this_dir = os.path.dirname(os.path.dirname(__file__))
if this_dir not in sys.path:
    sys.path.insert(0, this_dir)

from app import create_app
from flask import render_template

app = create_app()
with app.app_context():
    # render with a minimal dummy form to avoid template errors
    class Dummy:
        def hidden_tag(self):
            return ''
        def __getattr__(self, name):
            return lambda *a, **k: ''

    try:
        html = render_template('auth/login.html', form=Dummy())
        out = os.path.join(os.path.dirname(__file__), 'login_render_output.html')
        open(out,'w',encoding='utf-8').write(html)
        print('WROTE', out)
    except Exception as e:
        tb = str(e)
        out = os.path.join(os.path.dirname(__file__), 'login_render_error.txt')
        open(out,'w',encoding='utf-8').write(tb)
        print('ERROR WRITTEN', out)
