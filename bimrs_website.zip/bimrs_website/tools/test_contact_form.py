import os
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app import create_app

if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        client = app.test_client()
        payload = {
            "name": "Contact Tester",
            "email": "tester@example.com",
            "subject": "Contact Form Test",
            "message": "Testing contact form delivery to noreplybimrs@gmail.com."
        }
        print("[TEST] Posting to /contact with payload:", payload)
        resp = client.post("/contact", json=payload)
        print("[HTTP] Status:", resp.status_code)
        try:
            data = resp.get_json()
        except Exception:
            data = None
        print("[RESULT]", data)
        if not data or not data.get("success"):
            raise SystemExit(1)
        print("[OK] Contact form email request sent successfully.")
