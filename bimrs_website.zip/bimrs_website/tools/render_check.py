import os
import sys
from flask import render_template

os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app import create_app  # noqa: E402
from app.forms.infra_forms import InfrastructureForm  # noqa: E402


def main():
    app = create_app()
    outputs = {}

    with app.test_request_context("/"):
        outputs["admin_dashboard"] = render_template(
            "admin/dashboard.html",
            total_reports=5,
            pending=2,
            in_progress=1,
            resolved=2,
            infras=4,
        )
        outputs["admin_reports_feed"] = render_template(
            "admin/reports_feed.html",
            reports=[],
        )
        outputs["resident_my_reports"] = render_template(
            "resident/my_reports.html",
            reports=[],
        )
        outputs["infra_manage"] = render_template(
            "admin/infrastructures.html",
            form=InfrastructureForm(),
            infras=[],
        )

    for name, html in outputs.items():
        print(f"{name}: {len(html)} chars")


if __name__ == "__main__":
    main()

