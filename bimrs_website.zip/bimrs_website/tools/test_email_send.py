import os
import sys

# Ensure project root is on sys.path when running via absolute path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app import create_app
from app.utils.email_helpers import send_email

if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        to = os.environ.get("MAIL_TEST_TO") or app.config.get("MAIL_USERNAME") or app.config.get("MAIL_DEFAULT_SENDER")
        subject = "BIMRS Email Test"
        body = "This is a test email from BIMRS. If you received this, SMTP is working."
        html = "<p>This is a <strong>test email</strong> from BIMRS.</p>"
        print(f"[TEST] Sending to: {to}")
        ok = send_email(subject, [to], body, html=html)
        print("[RESULT]", "SUCCESS" if ok else "FAILED")
