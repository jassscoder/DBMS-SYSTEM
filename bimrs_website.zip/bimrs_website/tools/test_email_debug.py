"""
Quick email debug test to see what's failing
"""
import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from app.utils.email_helpers import send_email

def test_email():
    app = create_app()
    
    with app.app_context():
        print("=" * 60)
        print("EMAIL CONFIGURATION DEBUG")
        print("=" * 60)
        print(f"MAIL_SERVER: {app.config.get('MAIL_SERVER')}")
        print(f"MAIL_PORT: {app.config.get('MAIL_PORT')}")
        print(f"MAIL_USE_TLS: {app.config.get('MAIL_USE_TLS')}")
        print(f"MAIL_USERNAME: {app.config.get('MAIL_USERNAME')}")
        print(f"MAIL_PASSWORD: {'*' * len(app.config.get('MAIL_PASSWORD', '')) if app.config.get('MAIL_PASSWORD') else 'NOT SET'}")
        print(f"MAIL_DEFAULT_SENDER: {app.config.get('MAIL_DEFAULT_SENDER')}")
        print("=" * 60)
        
        print("\nTesting email send...")
        
        try:
            result = send_email(
                subject="Test Email from BIMRS",
                recipients=["noreplybimrs@gmail.com"],
                body="This is a test email to verify email functionality.",
                html="<h1>Test Email</h1><p>This is a test email to verify email functionality.</p>"
            )
            
            if result:
                print("✓ EMAIL SENT SUCCESSFULLY!")
            else:
                print("✗ EMAIL FAILED TO SEND (returned False)")
                
        except Exception as e:
            print(f"✗ EXCEPTION OCCURRED: {type(e).__name__}")
            print(f"   Error: {str(e)}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    test_email()
