"""
Test Image Upload Functionality
Verifies that image uploads work correctly in the report submission form.
"""

import os
import sys
from io import BytesIO

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app import create_app
from app.utils.image_helpers import save_image, allowed_file


def test_allowed_file():
    """Test file extension validation."""
    print("=== Testing File Extension Validation ===")
    
    test_cases = [
        ("image.jpg", True),
        ("image.jpeg", True),
        ("image.png", True),
        ("image.gif", True),
        ("image.JPG", True),
        ("image.JPEG", True),
        ("document.pdf", False),
        ("script.js", False),
        ("file.txt", False),
        ("noextension", False),
        ("", False),
    ]
    
    all_passed = True
    for filename, expected in test_cases:
        result = allowed_file(filename)
        status = "[OK]" if result == expected else "[FAIL]"
        if result != expected:
            all_passed = False
        print(f"  {status} {filename}: {result} (expected {expected})")
    
    return all_passed


def test_upload_folder():
    """Test upload folder exists and is writable."""
    print("\n=== Testing Upload Folder ===")
    
    app = create_app()
    with app.app_context():
        upload_folder = app.config.get("UPLOAD_FOLDER")
        print(f"Upload folder: {upload_folder}")
        
        if not upload_folder:
            print("  [FAIL] UPLOAD_FOLDER not configured")
            return False
        
        if not os.path.exists(upload_folder):
            print("  [FAIL] Upload folder does not exist")
            return False
        
        if not os.path.isdir(upload_folder):
            print("  [FAIL] Upload folder is not a directory")
            return False
        
        if not os.access(upload_folder, os.W_OK):
            print("  [FAIL] Upload folder is not writable")
            return False
        
        print("  [OK] Upload folder exists and is writable")
        return True


def test_file_upload_simulation():
    """Simulate a file upload."""
    print("\n=== Testing File Upload Simulation ===")
    
    app = create_app()
    
    # Create a mock file object
    class MockFileStorage:
        def __init__(self, filename, content=b"fake image data"):
            self.filename = filename
            self.content = content
            self.stream = BytesIO(content)
        
        def save(self, path):
            with open(path, 'wb') as f:
                f.write(self.content)
    
    test_cases = [
        ("test_image.jpg", True, "Valid JPG file"),
        ("test_image.png", True, "Valid PNG file"),
        ("test_document.pdf", False, "Invalid PDF file"),
        ("", False, "Empty filename"),
    ]
    
    all_passed = True
    with app.app_context():
        for filename, should_succeed, description in test_cases:
            try:
                if filename:
                    mock_file = MockFileStorage(filename)
                    result = save_image(mock_file)
                    
                    if should_succeed:
                        print(f"  [OK] {description}: Saved as {result}")
                        
                        # Clean up test file
                        upload_folder = app.config.get("UPLOAD_FOLDER")
                        test_path = os.path.join(upload_folder, result)
                        if os.path.exists(test_path):
                            os.remove(test_path)
                    else:
                        print(f"  [FAIL] {description}: Should have failed but succeeded")
                        all_passed = False
                else:
                    # Test with None or empty
                    save_image(None)
                    print(f"  [FAIL] {description}: Should have raised ValueError")
                    all_passed = False
                    
            except ValueError as e:
                if not should_succeed:
                    print(f"  [OK] {description}: Correctly rejected ({e})")
                else:
                    print(f"  [FAIL] {description}: Unexpected error - {e}")
                    all_passed = False
            except Exception as e:
                print(f"  [FAIL] {description}: Unexpected exception - {e}")
                all_passed = False
    
    return all_passed


def test_form_import():
    """Test that form imports are correct."""
    print("\n=== Testing Form Imports ===")
    
    try:
        from app import create_app
        from app.forms.report_forms import ReportForm
        from flask_wtf.file import FileField, FileAllowed
        
        app = create_app()
        with app.app_context():
            with app.test_request_context():
                # Check if form uses correct FileField
                form_class = ReportForm()
                image_field = form_class.image
                
                print(f"  Form imported: {ReportForm}")
                print(f"  Image field type: {type(image_field)}")
                
                # Check if FileAllowed validator is present
                has_file_allowed = any(
                    isinstance(validator, FileAllowed) 
                    for validator in image_field.validators
                )
                
                if has_file_allowed:
                    print(f"  [OK] Form has FileAllowed validator")
                else:
                    print(f"  [WARNING] Form missing FileAllowed validator")
                
                print(f"  [OK] Form imports correctly")
                return True
    except Exception as e:
        print(f"  [FAIL] Form import error: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests."""
    print("="*70)
    print("           IMAGE UPLOAD FUNCTIONALITY TEST")
    print("="*70)
    
    results = []
    
    results.append(("File Extension Validation", test_allowed_file()))
    results.append(("Upload Folder Check", test_upload_folder()))
    results.append(("Form Import", test_form_import()))
    results.append(("File Upload Simulation", test_file_upload_simulation()))
    
    print("\n" + "="*70)
    print("                    TEST RESULTS")
    print("="*70)
    
    for test_name, passed in results:
        status = "[PASS]" if passed else "[FAIL]"
        print(f"  {status} {test_name}")
    
    all_passed = all(result[1] for result in results)
    
    print("="*70)
    if all_passed:
        print("  ALL TESTS PASSED - Image upload functionality is working!")
    else:
        print("  SOME TESTS FAILED - Please review the issues above")
    print("="*70)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
