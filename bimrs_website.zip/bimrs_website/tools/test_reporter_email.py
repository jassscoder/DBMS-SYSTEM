import os
import sys
from datetime import datetime

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app import create_app
from app.models.report import Report
from app.models.user import User
from app.extensions import db
from app.utils.email_helpers import send_report_status_email

TEST_EMAIL = "ivangabrielreyes6@gmail.com"

if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        # Ensure tables exist (useful for SQLite test DB)
        try:
            db.create_all()
            print("[INIT] Database tables ensured (create_all)")
        except Exception as e:
            print(f"[WARN] Could not ensure tables: {e}")

        # Ensure a test user exists
        user = User.query.filter_by(email=TEST_EMAIL).first()
        if not user:
            user = User(username="test_reporter", email=TEST_EMAIL, role="resident", is_suspended=False)
            user.set_password("TestPass123!")
            db.session.add(user)
            db.session.commit()
            print(f"[SETUP] Created test user {user.id} with email {TEST_EMAIL}")
        else:
            print(f"[SETUP] Using existing user {user.id} with email {TEST_EMAIL}")

        # Create a transient report object for email template; commit to get id
        report = Report(
            reporter_id=user.id,
            title="Test Broken Streetlight",
            category="Lighting",
            description="Streetlight not working near the plaza.",
            address="Población Barangay III",
            contact_number="09123456789",
            image_path=None,
            infrastructure_id=None,
            status="PENDING",
            created_at=datetime.utcnow()
        )
        db.session.add(report)
        db.session.commit()
        print(f"[SETUP] Created test report #{report.id} for {TEST_EMAIL}")

        # Send PENDING notification to reporter
        ok = send_report_status_email(report, old_status=None)
        print("[RESULT]", "SUCCESS" if ok else "FAILED")
