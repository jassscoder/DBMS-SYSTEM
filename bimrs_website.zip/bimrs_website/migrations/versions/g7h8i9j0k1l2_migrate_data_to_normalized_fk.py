"""migrate data from string columns to normalized FK columns

Revision ID: g7h8i9j0k1l2
Revises: f6g7h8i9j0k1
Create Date: 2025-12-17 10:05:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import text


# revision identifiers, used by Alembic.
revision = 'g7h8i9j0k1l2'
down_revision = 'f6g7h8i9j0k1'
branch_labels = None
depends_on = None


def upgrade():
    connection = op.get_bind()
    
    # Migrate infrastructure categories
    # First, get all unique categories from infrastructure
    categories_result = connection.execute(
        text("SELECT DISTINCT LOWER(category) as category FROM infrastructure WHERE category IS NOT NULL")
    )
    
    # Insert into category table (case-insensitive)
    for row in categories_result:
        if row[0]:
            # Try to insert, ignore if already exists
            try:
                connection.execute(
                    text(f"INSERT INTO category (name) VALUES ('{row[0].title()}')")
                )
            except:
                pass
    
    # Update infrastructure.category_id with corresponding category IDs
    connection.execute(
        text("""
            UPDATE infrastructure 
            SET category_id = (
                SELECT id FROM category WHERE LOWER(category.name) = LOWER(infrastructure.category)
            )
            WHERE category IS NOT NULL AND category_id IS NULL
        """)
    )
    
    # Migrate reports categories
    categories_result = connection.execute(
        text("SELECT DISTINCT LOWER(category) as category FROM reports WHERE category IS NOT NULL")
    )
    
    # Insert into category table
    for row in categories_result:
        if row[0]:
            try:
                connection.execute(
                    text(f"INSERT INTO category (name) VALUES ('{row[0].title()}')")
                )
            except:
                pass
    
    # Update reports.category_id with corresponding category IDs
    connection.execute(
        text("""
            UPDATE reports 
            SET category_id = (
                SELECT id FROM category WHERE LOWER(category.name) = LOWER(reports.category)
            )
            WHERE category IS NOT NULL AND category_id IS NULL
        """)
    )


def downgrade():
    # No data migration in downgrade - the tables will be dropped in the previous migration
    pass
