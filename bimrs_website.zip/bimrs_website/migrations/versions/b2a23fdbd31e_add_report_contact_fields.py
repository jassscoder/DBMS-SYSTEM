"""add address and contact number to reports

Revision ID: b2a23fdbd31e
Revises: 4ecb0b536d5b
Create Date: 2025-11-24 18:30:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b2a23fdbd31e'
down_revision = '4ecb0b536d5b'
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table('reports', schema=None) as batch_op:
        batch_op.add_column(sa.Column('address', sa.String(length=255), nullable=True))
        batch_op.add_column(sa.Column('contact_number', sa.String(length=50), nullable=True))


def downgrade():
    with op.batch_alter_table('reports', schema=None) as batch_op:
        batch_op.drop_column('contact_number')
        batch_op.drop_column('address')

