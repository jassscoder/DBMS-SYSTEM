"""update feedback model with report_id and rating

Revision ID: d4e5f6g7h8i9
Revises: c3d4e5f6g7h8
Create Date: 2025-12-12 10:30:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd4e5f6g7h8i9'
down_revision = 'c3d4e5f6g7h8'
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table('feedback', schema=None) as batch_op:
        batch_op.add_column(sa.Column('report_id', sa.Integer(), nullable=False, server_default='1'))
        batch_op.add_column(sa.Column('rating', sa.Integer(), nullable=True))
        batch_op.create_foreign_key('fk_feedback_report_id', 'reports', ['report_id'], ['id'])


def downgrade():
    with op.batch_alter_table('feedback', schema=None) as batch_op:
        batch_op.drop_constraint('fk_feedback_report_id', type_='foreignkey')
        batch_op.drop_column('rating')
        batch_op.drop_column('report_id')
