"""add name field to users

Revision ID: e5f6g7h8i9j0
Revises: d4e5f6g7h8i9
Create Date: 2025-12-12 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e5f6g7h8i9j0'
down_revision = 'd4e5f6g7h8i9'
branch_labels = None
depends_on = None


def upgrade():
    # Add name column to users table
    op.add_column('users', sa.Column('name', sa.String(length=100), nullable=True))


def downgrade():
    # Remove name column from users table
    op.drop_column('users', 'name')
