"""make category_id not nullable and drop old string columns

Revision ID: h8i9j0k1l2m3
Revises: g7h8i9j0k1l2
Create Date: 2025-12-17 10:10:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'h8i9j0k1l2m3'
down_revision = 'g7h8i9j0k1l2'
branch_labels = None
depends_on = None


def upgrade():
    # Make category_id NOT NULL in infrastructure
    with op.batch_alter_table('infrastructure', schema=None) as batch_op:
        batch_op.alter_column('category_id', existing_type=sa.Integer(), nullable=False)
    
    # Make category_id NOT NULL in reports
    with op.batch_alter_table('reports', schema=None) as batch_op:
        batch_op.alter_column('category_id', existing_type=sa.Integer(), nullable=False)
    
    # Drop the old string columns
    with op.batch_alter_table('infrastructure', schema=None) as batch_op:
        batch_op.drop_column('category')
    
    with op.batch_alter_table('reports', schema=None) as batch_op:
        batch_op.drop_column('category')


def downgrade():
    # Re-add the old string columns
    with op.batch_alter_table('reports', schema=None) as batch_op:
        batch_op.add_column(sa.Column('category', sa.String(100), nullable=True))
    
    with op.batch_alter_table('infrastructure', schema=None) as batch_op:
        batch_op.add_column(sa.Column('category', sa.String(80), nullable=True))
    
    # Make category_id nullable again
    with op.batch_alter_table('reports', schema=None) as batch_op:
        batch_op.alter_column('category_id', existing_type=sa.Integer(), nullable=True)
    
    with op.batch_alter_table('infrastructure', schema=None) as batch_op:
        batch_op.alter_column('category_id', existing_type=sa.Integer(), nullable=True)
