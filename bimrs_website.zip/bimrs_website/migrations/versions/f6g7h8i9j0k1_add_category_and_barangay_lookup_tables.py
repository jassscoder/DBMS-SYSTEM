"""add category lookup table and normalize infrastructure/reports

Revision ID: f6g7h8i9j0k1
Revises: e5f6g7h8i9j0
Create Date: 2025-12-17 10:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f6g7h8i9j0k1'
down_revision = 'e5f6g7h8i9j0'
branch_labels = None
depends_on = None


def upgrade():
    # Create category table
    op.create_table(
        'category',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(80), nullable=False, unique=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name'),
        sa.Index('ix_category_name', 'name')
    )
    
    # Add category_id column to infrastructure
    with op.batch_alter_table('infrastructure', schema=None) as batch_op:
        batch_op.add_column(sa.Column('category_id', sa.Integer(), nullable=True))
        batch_op.create_foreign_key('fk_infrastructure_category', 'category', ['category_id'], ['id'])
    
    # Add category_id column to reports
    with op.batch_alter_table('reports', schema=None) as batch_op:
        batch_op.add_column(sa.Column('category_id', sa.Integer(), nullable=True))
        batch_op.create_foreign_key('fk_reports_category', 'category', ['category_id'], ['id'])


def downgrade():
    # Drop foreign keys and columns from reports
    with op.batch_alter_table('reports', schema=None) as batch_op:
        batch_op.drop_constraint('fk_reports_category', type_='foreignkey')
        batch_op.drop_column('category_id')
    
    # Drop foreign keys and columns from infrastructure
    with op.batch_alter_table('infrastructure', schema=None) as batch_op:
        batch_op.drop_constraint('fk_infrastructure_category', type_='foreignkey')
        batch_op.drop_column('category_id')
    
    # Drop category table
    op.drop_table('category')
